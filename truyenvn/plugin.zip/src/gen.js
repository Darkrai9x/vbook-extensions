load('config.js');
function execute(url, page) {
    page = page || "1";
    url = normalizeUrl(url);
    let response = fetch(url + (url.indexOf("?") === -1 ? "?" : "&") + "page=" + page);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let next = hasNextPage(doc, page) ? String(parseInt(page) + 1) : "";
    return Response.success(parseItems(doc), next);
}
