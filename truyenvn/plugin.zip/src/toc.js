load('config.js');

// The chapter list is loaded by the page's script from a CSRF-protected endpoint. The
// site's session lives only 60 s, so the first request after it expires can fail with
// HTTP 419; fetching the page again picks up the fresh session.
function fetchChapterHtml(url) {
    let response = fetch(url);
    if (!response.ok) return { status: response.status };
    let doc = response.html();
    let storyId = (doc.html().match(/"story_id"\s*:\s*(\d+)/) || [])[1];
    let token = doc.select("meta[name=csrf-token]").attr("content");
    if (!storyId || !token) return { error: "Không tìm thấy mã truyện" };

    let listResponse = fetch(BASE_URL + "/webapi/stories/list-chapter", {
        method: "POST",
        headers: {
            "X-Requested-With": "XMLHttpRequest",
            "Referer": url,
            "X-CSRF-TOKEN": token,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        },
        body: "story_id=" + storyId + "&routeName=story.detail"
    });
    if (!listResponse.ok) return { status: listResponse.status };
    let json = listResponse.json();
    if (!json.data || !json.data.html) return { error: "Không tải được danh sách chương" };
    return { html: json.data.html };
}

function execute(url) {
    url = normalizeUrl(url).replace(/\/$/, "");
    let result = fetchChapterHtml(url);
    if (result.status === 419) result = fetchChapterHtml(url);
    if (result.error) return Response.error(result.error);
    if (!result.html) return Response.error("HTTP " + result.status);

    let links = Html.parse(result.html).select(".wp-manga-chapter a");
    let chapters = [];
    for (let i = links.size() - 1; i >= 0; i--) {
        let e = links.get(i);
        chapters.push({ name: e.text().trim(), url: e.attr("href").trim() });
    }
    return Response.success(chapters);
}
