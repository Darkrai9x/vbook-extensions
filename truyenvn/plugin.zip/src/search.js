load('config.js');
function execute(key, page) {
    page = page || "1";
    let response = fetch(BASE_URL + "/tim-kiem", { queries: { search: key || "", page: page } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let next = hasNextPage(doc, page) ? String(parseInt(page) + 1) : "";
    return Response.success(parseItems(doc), next);
}
