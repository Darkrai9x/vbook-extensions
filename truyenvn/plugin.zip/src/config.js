let BASE_URL = "https://truyenvn.mobi";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}