let BASE_URL = "https://truyenvnhay.tv";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}