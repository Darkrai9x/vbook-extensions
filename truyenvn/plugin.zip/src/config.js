let BASE_URL = "https://truyenvn.my";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// Shared by the listing pages (.page-item-detail) and search results (.c-tabs-item__content).
function parseItems(doc) {
    let items = [];
    doc.select(".page-item-detail, .c-tabs-item__content").forEach(function (e) {
        let link = e.select(".post-title a").first();
        if (!link || !link.attr("href")) return;
        items.push({
            name: link.text(),
            link: link.attr("href").trim(),
            cover: e.select("img").first().attr("src"),
            description: e.select(".chapter a, .chapter-item a").first().text()
        });
    });
    return items;
}

function hasNextPage(doc, page) {
    return doc.select("a[href*='page=" + (parseInt(page) + 1) + "']").size() > 0;
}
