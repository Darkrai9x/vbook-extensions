let BASE_URL = "https://truyenvn.my";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// The imggo.net CDN answers 403 to any request carrying a Referer; the fragment tells
// the app to load the image without one, as the site's own <img referrerpolicy> does.
function imageUrl(src) {
    src = (src || "").trim();
    if (!src || src.indexOf("imggo.net/") === -1) return src;
    return src + "#referrerpolicy=no-referrer";
}

// Shared by the listing pages (.page-item-detail) and search results (.c-tabs-item__content).
function parseItems(doc) {
    let items = [];
    doc.select(".page-item-detail, .c-tabs-item__content").forEach(function (e) {
        let link = e.select(".post-title a").first();
        if (!link || !link.attr("href")) return;
        items.push({
            name: link.text(),
            link: link.attr("href").trim(),
            cover: imageUrl(e.select("img").first().attr("src")),
            description: e.select(".chapter a, .chapter-item a").first().text()
        });
    });
    return items;
}

function hasNextPage(doc, page) {
    return doc.select("a[href*='page=" + (parseInt(page) + 1) + "']").size() > 0;
}
