load('config.js');
function execute() {
    let response = fetch(BASE_URL + "/truyen-tranh");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let genres = [];
    let seen = {};
    doc.select("a[href*='/the-loai/']").forEach(function (e) {
        let href = e.attr("href").trim();
        let title = e.text().trim();
        if (!title || seen[href]) return;
        seen[href] = true;
        genres.push({ title: title, input: href, script: "gen.js" });
    });
    return Response.success(genres);
}
