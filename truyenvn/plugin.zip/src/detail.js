load('config.js');
function execute(url) {
    url = normalizeUrl(url).replace(/\/$/, "");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let info = {};
    doc.select(".post-content_item").forEach(function (e) {
        info[e.select(".summary-heading").text().trim()] = e.select(".summary-content").text().trim();
    });
    let status = info["Tình trạng"] || "";

    let genres = doc.select(".genres-content a").map(function (e) {
        return { title: e.text(), input: e.attr("href").trim(), script: "gen.js" };
    });

    return Response.success({
        name: doc.select(".post-title h1").first().text(),
        cover: doc.select(".summary_image img").first().attr("src"),
        author: info["Tác giả"] || "",
        description: doc.select(".description-summary .summary__content").html(),
        detail: "Tình trạng: " + status + (info["Xếp hạng"] ? "<br>Xếp hạng: " + info["Xếp hạng"] : ""),
        url: url,
        type: "comic",
        format: "comic",
        ongoing: status.indexOf("Completed") === -1 && status.indexOf("Hoàn") === -1,
        genres: genres
    });
}
