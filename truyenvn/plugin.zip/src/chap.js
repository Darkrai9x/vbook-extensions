load('config.js');
function execute(url) {
    url = normalizeUrl(url).replace(/\/$/, "");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let images = [];
    doc.select(".reading-content img.wp-manga-chapter-img").forEach(function (e) {
        let src = (e.attr("data-src") || e.attr("src")).trim();
        if (src) images.push(imageUrl(src));
    });
    if (images.length === 0) return Response.error("Không tìm thấy ảnh trong chương");
    return Response.success(images);
}
