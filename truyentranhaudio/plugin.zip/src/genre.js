function execute() {
    return Response.success([
        { title: "manhua", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-manhua.html", script: "gen.js" },
        { title: "manhwa", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-manhwa.html", script: "gen.js" },
        { title: "manga", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-manga.html", script: "gen.js" },
        { title: "hệ thống", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-he-thong.html", script: "gen.js" },
        { title: "đô thị", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-do-thi.html", script: "gen.js" },
        { title: "trọng sinh", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-trong-sinh.html", script: "gen.js" },
        { title: "trọng sinh", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-trong-sinh.html", script: "gen.js" },
        { title: "tu tiên", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-tu-tien.html", script: "gen.js" },
        { title: "harem", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-harem.html", script: "gen.js" },
        { title: "xuyên không", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-xuyen-khong.html", script: "gen.js" },
        { title: "game", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-game.html", script: "gen.js" },
        { title: "ma đạo", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-ma-dao.html", script: "gen.js" },
        { title: "ma đạo", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-ma-dao.html", script: "gen.js" },
        { title: "kinh dị", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-kinh-di.html", script: "gen.js" },
        { title: "đam mỹ", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-dam-my.html", script: "gen.js" },
        { title: "ngôn tình", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-ngon-tinh.html", script: "gen.js" },
        { title: "đấu trí", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-dau-tri.html", script: "gen.js" },
        { title: "hentai", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-hentai.html", script: "gen.js" },
        { title: "hentai", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-hentai.html", script: "gen.js" },
        { title: "hành động", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-hanh-dong.html", script: "gen.js" },
        { title: "phép thuật", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-phep-thuat.html", script: "gen.js" },
        { title: "huyền huyễn", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-huyen-huyen.html", script: "gen.js" },
        { title: "Action", input: "https://truyentranhaudio.online/danh-sach-truyen-the-loai-action.html", script: "gen.js" }
    ]);
}