function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: "https://truyentranhaudio.online/", script: "top.js"}
    ]);
}