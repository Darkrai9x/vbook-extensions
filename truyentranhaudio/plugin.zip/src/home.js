function execute() {
    return Response.success([
        {title: "Danh sách truyện", input: "https://truyentranhaudio.online/danh-sach-truyen.html", script: "gen.js"}
    ]);
}