var LLM_NAME = "Claude";
var LLM_ENDPOINT = "https://api.anthropic.com/v1/messages";
var LLM_API_VERSION = "2023-06-01";
var LLM_DEFAULT_MODEL = "claude-opus-5";
var LLM_ANALYSIS_MODEL = "claude-opus-5";
var LLM_SUPPORTS_TEMPERATURE = true;
var LLM_TEMPERATURE_NOTE = "; chỉ áp dụng cho Opus 4.6, Sonnet 4.6 và Haiku 4.5 (model mới hơn không hỗ trợ)";
var LLM_ROTATE_KEY_STATUSES = { 401: true, 403: true, 429: true };
// Non-streaming requests with thinking can run for minutes.
var LLM_MIN_TIMEOUT = 300000;
var LLM_FALLBACK_BETA = "server-side-fallback-2026-07-01";
// temperature: model accepts sampling params; effort: model accepts output_config.effort;
// fallback: re-run safety-classifier refusals on Anthropic's recommended model server-side.
var LLM_MODEL_INFO = {
    "claude-opus-5": { temperature: false, effort: true, fallback: true },
    "claude-fable-5-1": { temperature: false, effort: true, fallback: true },
    "claude-fable-5": { temperature: false, effort: true, fallback: false },
    "claude-opus-4-8": { temperature: false, effort: true, fallback: false },
    "claude-opus-4-7": { temperature: false, effort: true, fallback: false },
    "claude-opus-4-6": { temperature: true, effort: true, fallback: false },
    "claude-sonnet-5": { temperature: false, effort: true, fallback: false },
    "claude-sonnet-4-6": { temperature: true, effort: true, fallback: false },
    "claude-haiku-4-5": { temperature: true, effort: false, fallback: false }
};

function llmAddProviderConfig(config) {
    config[translationConfigKey("effort")] = {
        title: "Mức nỗ lực (effort)",
        subtitle: "low: nhanh, rẻ; high: dịch kỹ nhất nhưng chậm và tốn token. Không áp dụng cho Haiku 4.5",
        default: "medium",
        values: ["low", "medium", "high"],
        mode: "select",
        format: "single"
    };
}

function llmNormalizeModel(model) {
    var selected = String(model || "").trim();
    return LLM_MODEL_INFO[selected] ? selected : LLM_DEFAULT_MODEL;
}

function llmEffort() {
    var effort = "medium";
    try {
        effort = String(localConfig.getItem(translationConfigKey("effort")) || "medium");
    } catch (e) {}
    return effort === "low" || effort === "high" ? effort : "medium";
}

// options: { temperature, maxTokens, json }. JSON-only output is requested in the prompt itself.
function llmBuildBody(model, systemPrompt, userText, options) {
    options = options || {};
    model = llmNormalizeModel(model);
    var info = LLM_MODEL_INFO[model];
    var body = {
        model: model,
        max_tokens: options.maxTokens || 4096,
        system: systemPrompt,
        messages: [{ role: "user", content: userText }]
    };
    if (info.effort) body.output_config = { effort: llmEffort() };
    if (info.temperature && options.temperature !== undefined) body.temperature = options.temperature;
    if (info.fallback) body.fallbacks = "default";
    return body;
}

// Tries each key in order; rotates on auth/quota errors. Returns { text, finishReason, error, keyIndex }.
function llmRequest(apiKeys, body, timeout) {
    var payload = JSON.stringify(body);
    var headers = {
        "Content-Type": "application/json",
        "anthropic-version": LLM_API_VERSION
    };
    if (body.fallbacks) headers["anthropic-beta"] = LLM_FALLBACK_BETA;
    var lastError = "";
    for (var keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        headers["x-api-key"] = apiKeys[keyIndex];
        var response;
        try {
            response = fetch(LLM_ENDPOINT, {
                method: "POST",
                headers: headers,
                body: payload,
                timeout: Math.max(timeout || 0, LLM_MIN_TIMEOUT)
            });
        } catch (e) {
            lastError = LLM_NAME + ": " + String(e);
            continue;
        }

        if (!response.ok) {
            lastError = llmApiError(response);
            if (LLM_ROTATE_KEY_STATUSES[response.status]) continue;
            return { text: "", finishReason: "", error: lastError, keyIndex: keyIndex };
        }

        var data;
        try {
            data = JSON.parse(response.text());
        } catch (e2) {
            return { text: "", finishReason: "", error: LLM_NAME + " trả về dữ liệu không hợp lệ", keyIndex: keyIndex };
        }

        var text = "";
        var blocks = data && data.content ? data.content : [];
        for (var i = 0; i < blocks.length; i++) {
            if (blocks[i] && blocks[i].type === "text" && blocks[i].text) text += String(blocks[i].text);
        }
        var stopReason = data && data.stop_reason ? String(data.stop_reason) : "";
        if (stopReason === "refusal") {
            var category = data.stop_details && data.stop_details.category ? String(data.stop_details.category) : "";
            return { text: "", finishReason: "refusal" + (category ? " (" + category + ")" : ""), error: "", keyIndex: keyIndex };
        }
        return { text: text, finishReason: stopReason, error: "", keyIndex: keyIndex };
    }
    return { text: "", finishReason: "", error: lastError || "Không có " + LLM_NAME + " API key khả dụng", keyIndex: -1 };
}

function llmApiError(response) {
    var message = "";
    try {
        var data = JSON.parse(response.text());
        if (data && data.error && data.error.message) message = String(data.error.message);
    } catch (e) {}
    return LLM_NAME + " HTTP " + response.status + (message ? ": " + message : "");
}
