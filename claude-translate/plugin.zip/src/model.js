function execute() {
    return Response.success([
        { id: "claude-opus-5-5", name: "Claude Opus 5.5", description: "Mặc định; chất lượng dịch văn học cao, rẻ hơn Opus 5", isNetworkRequired: true },
        { id: "claude-fable-5-1", name: "Claude Fable 5.1", description: "Mạnh nhất; chậm và đắt nhất", isNetworkRequired: true },
        { id: "claude-sonnet-5-5", name: "Claude Sonnet 5.5", description: "Nhanh và rẻ hơn Opus, chất lượng tốt", isNetworkRequired: true },
        { id: "claude-haiku-5-5", name: "Claude Haiku 5.5", description: "Nhanh và rẻ nhất, hợp cho dịch số lượng lớn", isNetworkRequired: true },
        { id: "claude-fable-5", name: "Claude Fable 5", description: "Fable đời trước, rất mạnh; chậm và đắt", isNetworkRequired: true },
        { id: "claude-opus-5", name: "Claude Opus 5", description: "Opus đời trước, chất lượng cao", isNetworkRequired: true },
        { id: "claude-opus-4-8", name: "Claude Opus 4.8", description: "Opus đời cũ, chất lượng cao", isNetworkRequired: true },
        { id: "claude-opus-4-7", name: "Claude Opus 4.7", description: "Opus đời cũ", isNetworkRequired: true },
        { id: "claude-opus-4-6", name: "Claude Opus 4.6", description: "Opus đời cũ; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "claude-sonnet-5", name: "Claude Sonnet 5", description: "Sonnet đời trước", isNetworkRequired: true },
        { id: "claude-sonnet-4-6", name: "Claude Sonnet 4.6", description: "Sonnet đời cũ; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "claude-haiku-4-5", name: "Claude Haiku 4.5", description: "Haiku đời trước; hỗ trợ Temperature", isNetworkRequired: true }
    ]);
}
