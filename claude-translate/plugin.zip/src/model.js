function execute() {
    return Response.success([
        { id: "claude-opus-5", name: "Claude Opus 5", description: "Mặc định; chất lượng dịch văn học cao, cân bằng tốc độ", isNetworkRequired: true },
        { id: "claude-fable-5-1", name: "Claude Fable 5.1", description: "Mạnh nhất; chậm và đắt nhất", isNetworkRequired: true },
        { id: "claude-fable-5", name: "Claude Fable 5", description: "Fable đời trước, rất mạnh; chậm và đắt", isNetworkRequired: true },
        { id: "claude-opus-4-8", name: "Claude Opus 4.8", description: "Opus đời trước, chất lượng cao", isNetworkRequired: true },
        { id: "claude-opus-4-7", name: "Claude Opus 4.7", description: "Opus đời trước", isNetworkRequired: true },
        { id: "claude-opus-4-6", name: "Claude Opus 4.6", description: "Opus đời cũ; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "claude-sonnet-5", name: "Claude Sonnet 5", description: "Nhanh và rẻ hơn Opus, chất lượng tốt", isNetworkRequired: true },
        { id: "claude-sonnet-4-6", name: "Claude Sonnet 4.6", description: "Sonnet đời trước; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "claude-haiku-4-5", name: "Claude Haiku 4.5", description: "Nhanh và rẻ nhất; hỗ trợ Temperature", isNetworkRequired: true }
    ]);
}
