function execute() {
    return Response.success([
        {title: "Oneshot", input: "https://hentai2read.com/hentai-list/category/Oneshot/all/name-az", script: "gen.js"},
        {title: "Adult", input: "https://hentai2read.com/hentai-list/category/Adult/all/name-az", script: "gen.js"},
        {title: "Anal", input: "https://hentai2read.com/hentai-list/category/Anal/all/name-az", script: "gen.js"},
        {title: "Comedy", input: "https://hentai2read.com/hentai-list/category/Comedy/all/name-az", script: "gen.js"},
        {title: "Doujinshi", input: "https://hentai2read.com/hentai-list/category/Doujinshi/all/name-az", script: "gen.js"},
        {title: "Ecchi", input: "https://hentai2read.com/hentai-list/category/Ecchi/all/name-az", script: "gen.js"},
        {title: "Harem", input: "https://hentai2read.com/hentai-list/category/Harem/all/name-az", script: "gen.js"},
        {title: "Incest", input: "https://hentai2read.com/hentai-list/category/Incest/all/name-az", script: "gen.js"},
        {title: "Romance", input: "https://hentai2read.com/hentai-list/category/Romance/all/name-az", script: "gen.js"},
        {title: "Big Breasts", input: "https://hentai2read.com/hentai-list/category/Big%20Breasts/all/name-az", script: "gen.js"},
        {title: "Futanari", input: "https://hentai2read.com/hentai-list/category/Futanari/all/name-az", script: "gen.js"},
        {title: "Lactation", input: "https://hentai2read.com/hentai-list/category/Lactation/all/name-az", script: "gen.js"},
        {title: "Yaoi", input: "https://hentai2read.com/hentai-list/category/Yaoi/all/name-az", script: "gen.js"},
        {title: "Yuri", input: "https://hentai2read.com/hentai-list/category/Yuri/all/name-az", script: "gen.js"},
    ]);
}