load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let bid = doc.select("input[name=bid]").attr("value");
    if (!bid) return Response.error("Không tìm thấy mã truyện");

    // The TOC pager only exposes page numbers through onclick="page(bid, n)".
    let total = 1;
    doc.select("#chapter-list .paging a[onclick]").forEach(function (e) {
        let match = /page\(\s*\d+\s*,\s*(\d+)\s*\)/.exec(e.attr("onclick"));
        if (match && parseInt(match[1]) > total) total = parseInt(match[1]);
    });

    let pages = [];
    for (let i = 1; i <= total; i++) {
        pages.push(BASE_URL + "/get/listchap/" + bid + "?page=" + i);
    }
    return Response.success(pages);
}
