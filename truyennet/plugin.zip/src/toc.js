load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, {
        headers: { "X-Requested-With": "XMLHttpRequest" }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let json = response.json();
    let doc = Html.parse(json && json.data ? json.data : "");

    let chapters = [];
    doc.select("li a[href]").forEach(function (e) {
        let href = e.attr("href");
        if (href.indexOf("javascript") === 0) return;
        chapters.push({
            name: e.text(),
            url: absUrl(href),
            lock: false,
            pay: false
        });
    });
    return Response.success(chapters);
}
