load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let name = doc.select("h1[itemprop=name]").text();
    if (!name) return Response.error("Không tìm thấy truyện");

    let details = [];
    doc.select(".book-info-text li").forEach(function (e) {
        let text = e.text().trim();
        if (text && e.select("a[href^=/the-loai/]").isEmpty()) details.push(text);
    });

    let tags = doc.select(".li--genres a").map(function (e) {
        return { title: e.text(), input: absUrl(e.attr("href")), script: "list.js" };
    });

    let description = doc.select("[itemprop=description]").first();
    if (description) description.select("script, style").remove();

    return Response.success({
        name: name,
        author: doc.select("a[itemprop=author]").text(),
        cover: absUrl(doc.select(".book-info-pic img").attr("src")),
        description: description ? description.html() : "",
        detail: details.join("<br>"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: doc.select(".label-status.label-full").isEmpty(),
        tags: tags
    });
}
