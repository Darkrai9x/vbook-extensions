load('config.js');
function execute(url, page) {
    page = page || "1";
    let response = fetch(absUrl(url), { queries: { page: page } });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(parseBookList(doc), nextPageToken(doc));
}
