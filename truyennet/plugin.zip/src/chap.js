load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let content = doc.select("#story").first();
    if (!content) return Response.error("Không tìm thấy nội dung chương");
    content.select("script, style, iframe, ins, .ads").remove();

    return Response.success(content.html(), doc.select(".current-chapter").text());
}
