load('config.js');
function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let order = [];
    let titles = {};
    doc.select("a[href^=/the-loai/]").forEach(function (e) {
        let href = e.attr("href");
        let title = e.text().trim();
        if (!title) return;
        if (!titles[href]) {
            order.push(href);
            titles[href] = title;
        } else if (/^[a-zà-ỹ]/.test(titles[href]) && !/^[a-zà-ỹ]/.test(title)) {
            titles[href] = title;
        }
    });

    let genres = order.map(function (href) {
        return { title: titles[href], input: absUrl(href), script: "list.js" };
    });
    return Response.success(genres);
}
