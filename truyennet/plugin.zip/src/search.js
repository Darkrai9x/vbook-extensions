load('config.js');
function execute(query, page) {
    query = query || "";
    page = page || "1";

    let response = fetch(BASE_URL + "/tim-kiem", {
        queries: { s: query, page: page }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    return Response.success(parseBookList(doc), nextPageToken(doc));
}
