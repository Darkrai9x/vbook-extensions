let BASE_URL = "https://truyennet.org";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absUrl(href) {
    href = String(href || "").trim();
    if (!href) return "";
    if (href.indexOf("//") === 0) return "https:" + href;
    if (/^https?:\/\//i.test(href)) return href;
    if (href.charAt(0) !== "/") href = "/" + href;
    return BASE_URL + href;
}

function parseBookList(doc) {
    let items = [];
    doc.select(".truyen-list .item").forEach(function (e) {
        let link = e.select("h3 a").first();
        if (!link) return;
        let lines = [];
        e.select("p.line").forEach(function (line) {
            lines.push(line.text());
        });
        items.push({
            name: link.text(),
            link: absUrl(link.attr("href")),
            cover: absUrl(e.select("a.cover img").attr("src")),
            description: lines.join("\n"),
            tag: e.select(".status-full").isEmpty() ? "" : "Full"
        });
    });
    return items;
}

function nextPageToken(doc) {
    let next = "";
    doc.select(".phan-trang a.btn-page").forEach(function (e) {
        if (e.text().trim() === "❭") {
            let match = /[?&]page=(\d+)/.exec(e.attr("href"));
            if (match) next = match[1];
        }
    });
    return next;
}
