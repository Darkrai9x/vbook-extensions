function execute() {
    return Response.success([
        {title: "Truyện Hot", input: "https://sstruyen.vn/danh-sach/truyen-hot/", script: "gen.js"},
        {title: "Truyện mới cập nhật", input: "https://sstruyen.vn/danh-sach/truyen-moi-cap-nhat/", script: "gen.js"},
        {title: "Ngôn Tình Hay", input: "https://sstruyen.vn/danh-sach/ngon-tinh-hay/", script: "gen.js"},
        {title: "Truyện Teen Hay", input: "https://sstruyen.vn/danh-sach/truyen-teen-hay/", script: "gen.js"},
        {title: "Ngôn Tình Ngược", input: "https://sstruyen.vn/danh-sach/ngon-tinh-nguoc/", script: "gen.js"},
        {title: "Ngôn Tình Hài", input: "https://sstruyen.vn/danh-sach/ngon-tinh-hai/", script: "gen.js"},
        {title: "Đam Mỹ Hài", input: "https://sstruyen.vn/danh-sach/dam-my-hai/", script: "gen.js"},
        {title: "Đam Mỹ Hay", input: "https://sstruyen.vn/danh-sach/dam-my-hay/", script: "gen.js"},
        {title: "Đam Mỹ H Văn", input: "https://sstruyen.vn/danh-sach/dam-my-h-van/", script: "gen.js"},
        {title: "Ngôn Tình Hay", input: "https://sstruyen.vn/danh-sach/ngon-tinh-hay/", script: "gen.js"},
        {title: "Tiên Hiệp Hay", input: "https://sstruyen.vn/danh-sach/tien-hiep-hay/", script: "gen.js"},
        {title: "Ngôn Tình Sắc", input: "https://sstruyen.vn/danh-sach/ngon-tinh-sac/", script: "gen.js"},
        {title: "Kiếm Hiệp Hay", input: "https://sstruyen.vn/danh-sach/kiem-hiep-hay/", script: "gen.js"}
    ]);
}