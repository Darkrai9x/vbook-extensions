function execute(key, page) {
    let response = fetch("http://m.shubao45.com/s.php", {
        method: "POST",
        body: {
            type: "articlename",
            s: key
        }
    });

    if (response.ok) {
        let doc = response.html('gbk');
        let bookList = [];
        Console.log(doc)
        doc.select(".line").forEach(e => {
            bookList.push({
                name: e.select("a.blue").first().text(),
                link: e.select("a.blue").first().attr("href"),
                description: e.select("a[href~=author]").text(),
                host: "http://m.shubao45.com"
            });
        });
        return Response.success(bookList);
    }

    return null;
}