load('config.js');
// Thread search. XenForo only searches through a POST: the first page posts the keywords with
// the form's token and reads the result page it redirects to; `page` afterwards is the path
// of the next result page, as in list.js.
function execute(query, page) {
    if (page && page.indexOf("/") === 0) {
        let next = fetch(BASE_URL + page);
        if (!next.ok) return Response.error("HTTP " + next.status);
        return parseSearch(next.html());
    }
    query = (query || "").trim();
    if (!query) return Response.success([], "");

    let form = fetch(BASE_URL + "/search/");
    if (!form.ok) return Response.error("HTTP " + form.status);
    let token = form.html().select("html").attr("data-csrf");
    let result = fetch(BASE_URL + "/search/search", {
        method: "POST",
        // A string body: the object form is rejected with a security error.
        headers: { "Referer": BASE_URL + "/search/", "Content-Type": "application/x-www-form-urlencoded" },
        body: "keywords=" + encodeURIComponent(query) + "&t=thread&_xfToken=" + encodeURIComponent(token)
    });
    if (!result.ok) return Response.error("HTTP " + result.status);
    return parseSearch(result.html());
}
