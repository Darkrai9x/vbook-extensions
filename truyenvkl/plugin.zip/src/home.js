function execute() {
    return Response.success([
        {title: "Truyện hot", script: "hot.js", input: "https://truyenhd1.com/truyen HOT top-all"},
        {title: "Truyện sáng tác", script: "hot.js", input: "https://truyenhd1.com/truyen-sang-tac SANGTAC new-chap"}
    ])
}