function execute() {
    return Response.success([
        {title: "Truyện Hot", script: "hot.js", input: "https://truyenvkl.com/tim-kiem/hot/"}
    ])
}