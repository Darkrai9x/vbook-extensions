load('config.js');
// The tabs of the web's top menu.
function execute() {
    return Response.success([
        { title: "Trang chủ", input: "", script: "feed.js", type: "explore" },
        { title: "Bài mới", input: "/whats-new/posts/", script: "list.js" },
        { title: "Diễn đàn", input: "", script: "explore.js", type: "explore" },
        { title: "Funland", input: "/forums/quan-cafe-otofun.77/", script: "list.js" },
        { title: "Chợ giời", input: "/forums/cho-gioi.89/", script: "list.js" }
    ]);
}
