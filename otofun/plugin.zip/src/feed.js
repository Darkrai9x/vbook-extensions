load('config.js');
// The web's home page: its portal widgets, in order — a grid of classifieds (Mua bán) and
// lists of the newest threads of the site and of a few boards.
function execute() {
    let response = fetch(BASE_URL + "/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    cleanNames(doc);

    let sections = [];
    doc.select(".block[data-widget-key]").forEach(function (block) {
        let header = block.select(".block-minorHeader").first();
        let title = header ? header.text().trim() : "";
        let link = header && header.select("a").first() ? header.select("a").first().attr("href") : "";
        let more = link ? { type: "list", name: title, script: "list.js", input: link.replace(/\?.*$/, "") } : undefined;

        let cards = block.select(".grid-thread__item");
        if (cards.size() > 0) {
            let items = cards.map(function (el) {
                let a = el.select(".grid-thread__text--title a").first();
                let img = el.select("img.block-cover__img").first();
                if (!a) return null;
                return {
                    name: a.text().trim(),
                    link: absUrl(a.attr("href")),
                    cover: img ? assetUrl(img.attr("src")) : "",
                    description: el.select(".grid-thread__text--invert").text().trim(),
                    tag: el.select(".grid-thread__text--meta .username").text().trim()
                };
            }).filter(function (x) { return x; });
            if (items.length > 0) {
                sections.push({ id: block.attr("data-widget-key"), title: title, type: "horizontal_list", items: items });
            }
            return;
        }

        let rows = block.select(".block-row .contentRow");
        if (rows.size() === 0) return;
        let items = rows.map(function (el) {
            let a = el.select(".contentRow-main > a").first();
            if (!a) return null;
            let avatar = el.select(".contentRow-figure img").first();
            let author = el.select(".contentRow-minor li").first();
            let replies = "";
            el.select(".contentRow-minor li").forEach(function (li) {
                let m = li.text().match(/^Trả lời:\s*(.+)$/);
                if (m) replies = m[1];
            });
            let time = el.select(".contentRow-minor time").first();
            let board = el.select(".contentRow-main > .contentRow-minor > a").first();
            return {
                name: escapeHtml(a.text().replace(/\u00a0/g, " ").trim()),
                link: absUrl(a.attr("href")),
                author: author ? author.text().replace(/^Started by\s*/, "").trim() : "",
                avatar: avatar ? assetUrl(avatar.attr("src")) : "",
                time: time ? (time.attr("data-time") || time.text()) : "",
                replies: replies,
                board: board ? board.text() : ""
            };
        }).filter(function (x) { return x; });
        if (items.length > 0) {
            let section = { id: block.attr("data-widget-key"), title: title, type: "thread_list", items: items };
            if (more) section.more = more;
            sections.push(section);
        }
    });
    if (sections.length === 0) return Response.error("Không tải được trang chủ");
    return Response.success(sections);
}
