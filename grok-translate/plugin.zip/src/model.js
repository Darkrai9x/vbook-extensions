function execute() {
    return Response.success([
        { id: "grok-4.20-0309-non-reasoning", name: "Grok 4.20", description: "Mặc định; không suy luận, nhanh và rẻ, hợp cho dịch số lượng lớn; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "grok-4.20-0309-reasoning", name: "Grok 4.20 Reasoning", description: "Grok 4.20 có suy luận trước khi dịch; kỹ hơn nhưng chậm hơn", isNetworkRequired: true },
        { id: "grok-4.3", name: "Grok 4.3", description: "Cùng giá Grok 4.20, ngữ cảnh 1M token", isNetworkRequired: true },
        { id: "grok-4.5", name: "Grok 4.5", description: "Model suy luận; chất lượng cao, đắt hơn", isNetworkRequired: true },
        { id: "grok-4.6", name: "Grok 4.6", description: "Model suy luận đời trước Grok 4.7", isNetworkRequired: true },
        { id: "grok-4.7", name: "Grok 4.7", description: "Mạnh nhất; suy luận, chậm và đắt nhất", isNetworkRequired: true }
    ]);
}
