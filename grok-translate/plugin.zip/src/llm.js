var LLM_NAME = "Grok";
var LLM_ENDPOINT = "https://api.x.ai/v1/chat/completions";
var LLM_DEFAULT_MODEL = "grok-4.20-0309-non-reasoning";
var LLM_ANALYSIS_MODEL = "grok-4.20-0309-non-reasoning";
var LLM_SUPPORTS_TEMPERATURE = true;
var LLM_TEMPERATURE_NOTE = "; Grok 4.5 trở lên là model suy luận nên bỏ qua Temperature";
var LLM_ROTATE_KEY_STATUSES = { 401: true, 403: true, 429: true };
// Reasoning requests can run for minutes.
var LLM_MIN_TIMEOUT = 300000;
// effort: model accepts reasoning_effort (and ignores temperature).
var LLM_MODEL_INFO = {
    "grok-4.20-0309-non-reasoning": { effort: false },
    "grok-4.20-0309-reasoning": { effort: false },
    "grok-4.3": { effort: false },
    "grok-4.5": { effort: true },
    "grok-4.6": { effort: true },
    "grok-4.7": { effort: true }
};

function llmAddProviderConfig(config) {
    config[translationConfigKey("reasoning_effort")] = {
        title: "Mức suy luận (reasoning effort)",
        subtitle: "Chỉ áp dụng cho Grok 4.5, 4.6, 4.7. low: nhanh, rẻ; high: dịch kỹ hơn nhưng chậm và tốn token hơn",
        default: "low",
        values: ["low", "medium", "high"],
        mode: "select",
        format: "single"
    };
}

function llmNormalizeModel(model) {
    var selected = String(model || "").trim();
    return LLM_MODEL_INFO[selected] ? selected : LLM_DEFAULT_MODEL;
}

function llmReasoningEffort() {
    var effort = "low";
    try {
        effort = String(localConfig.getItem(translationConfigKey("reasoning_effort")) || "low");
    } catch (e) {}
    return effort === "medium" || effort === "high" ? effort : "low";
}

// options: { temperature, maxTokens, json }
function llmBuildBody(model, systemPrompt, userText, options) {
    options = options || {};
    model = llmNormalizeModel(model);
    var body = {
        model: model,
        messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userText }
        ],
        max_tokens: options.maxTokens || 4096,
        stream: false
    };
    if (LLM_MODEL_INFO[model].effort) {
        body.reasoning_effort = llmReasoningEffort();
    } else if (options.temperature !== undefined) {
        body.temperature = options.temperature;
    }
    if (options.json) body.response_format = { type: "json_object" };
    return body;
}

// Tries each key in order; rotates on auth/quota errors. Returns { text, finishReason, error, keyIndex }.
function llmRequest(apiKeys, body, timeout) {
    var payload = JSON.stringify(body);
    var lastError = "";
    for (var keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        var response;
        try {
            response = fetch(LLM_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apiKeys[keyIndex]
                },
                body: payload,
                timeout: Math.max(timeout || 0, LLM_MIN_TIMEOUT)
            });
        } catch (e) {
            lastError = LLM_NAME + ": " + String(e);
            continue;
        }

        if (!response.ok) {
            var message = llmApiMessage(response);
            lastError = LLM_NAME + " HTTP " + response.status + (message ? ": " + message : "");
            // xAI answers an invalid key with 400 rather than 401.
            if (LLM_ROTATE_KEY_STATUSES[response.status] || (response.status === 400 && /api key/i.test(message))) continue;
            return { text: "", finishReason: "", error: lastError, keyIndex: keyIndex };
        }

        var data;
        try {
            data = JSON.parse(response.text());
        } catch (e2) {
            return { text: "", finishReason: "", error: LLM_NAME + " trả về dữ liệu không hợp lệ", keyIndex: keyIndex };
        }

        var choice = data && data.choices && data.choices.length > 0 ? data.choices[0] : null;
        var content = choice && choice.message ? choice.message : null;
        var finishReason = choice && choice.finish_reason ? String(choice.finish_reason) : "";
        if (content && content.refusal && !content.content) finishReason = "refusal: " + String(content.refusal);
        return {
            text: content && content.content ? String(content.content) : "",
            finishReason: finishReason,
            error: "",
            keyIndex: keyIndex
        };
    }
    return { text: "", finishReason: "", error: lastError || "Không có " + LLM_NAME + " API key khả dụng", keyIndex: -1 };
}

// xAI errors come either as { error: { message } } or as { code, error: "<message>" }.
function llmApiMessage(response) {
    try {
        var data = JSON.parse(response.text());
        if (data && data.error && data.error.message) return String(data.error.message);
        if (data && typeof data.error === "string") return data.error;
    } catch (e) {}
    return "";
}
