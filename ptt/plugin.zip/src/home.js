load('config.js');
// The hot boards, then a few busy boards as tabs.
function execute() {
    return Response.success([
        { title: "熱門看板", input: "", script: "explore.js", type: "explore" },
        { title: "C_Chat", input: "C_Chat", script: "list.js" },
        { title: "movie", input: "movie", script: "list.js" },
        { title: "Stock", input: "Stock", script: "list.js" },
        { title: "car", input: "car", script: "list.js" },
        { title: "Tech_Job", input: "Tech_Job", script: "list.js" }
    ]);
}
