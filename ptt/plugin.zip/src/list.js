load('config.js');
// Posts of a board, newest first. `input` is a board name; `page` is the path of the next older
// index page, "" on the first call.
function execute(input, page) {
    let path = page && page.indexOf("/bbs/") === 0 ? page : boardPath(input);
    let response = fetch(BASE_URL + path);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    if (isAgeGate(response, doc)) return Response.error("Bản này yêu cầu xác nhận đủ 18 tuổi, extension không hỗ trợ");

    // posts under .r-list-sep are the pinned ones; the index page lists oldest first
    let pinnedFrom = -1;
    let rows = doc.select(".r-ent, .r-list-sep");
    let items = [];
    rows.forEach(function (el) {
        if ((el.attr("class") || "").indexOf("r-list-sep") !== -1) {
            pinnedFrom = items.length;
            return;
        }
        let a = el.select(".title a").first();
        if (!a) return;
        let nrec = el.select(".nrec span").first();
        items.push({
            name: escapeHtml(a.text().trim()),
            link: absUrl(a.attr("href")),
            author: el.select(".author").text().trim(),
            time: el.select(".date").text().trim(),
            replies: nrec ? nrec.text().trim() : "0",
            hot: !!nrec && nrec.text().trim() === "爆",
            pinned: false
        });
    });
    if (pinnedFrom >= 0) {
        for (let i = pinnedFrom; i < items.length; i++) items[i].pinned = true;
    }
    items.reverse();
    // the pinned posts only make sense on the newest page
    if (page) items = items.filter(function (x) { return !x.pinned; });

    let older = doc.select("a.btn.wide:contains(上頁)").first();
    let next = older ? older.attr("href") : "";
    return Response.success(items, next && next.indexOf("/bbs/") === 0 ? next : "");
}
