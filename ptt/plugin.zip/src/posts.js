load('config.js');
const PUSH_PAGE = 50;
// One article: the post first, then its pushes (推 / 噓 / →), PUSH_PAGE of them per page.
// `page` is the page number, "" on the first call.
function execute(url, page) {
    let current = parseInt(page || "1") || 1;
    let response = fetch(normalizeUrl(url));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    if (isAgeGate(response, doc)) return Response.error("Bài viết yêu cầu xác nhận đủ 18 tuổi, extension không hỗ trợ");
    let main = doc.select("#main-content").first();
    if (!main) return Response.error("Không đọc được bài viết");

    let pushes = main.select(".push");
    let total = Math.max(1, Math.ceil(pushes.size() / PUSH_PAGE));
    let posts = [];

    if (current === 1) {
        let meta = {};
        main.select(".article-metaline, .article-metaline-right").forEach(function (m) {
            meta[m.select(".article-meta-tag").text().trim()] = m.select(".article-meta-value").text().trim();
        });
        // the body is what remains once the header lines and the pushes are taken out
        main.select(".article-metaline, .article-metaline-right, .push").remove();
        let author = meta["作者"] || "";
        let m = author.match(/^(\S+)\s*\((.*)\)$/);
        posts.push({
            id: "post",
            floor: "",
            url: normalizeUrl(url),
            is_op: true,
            time: meta["時間"] || "",
            user: { name: m ? m[1] : author, title: m ? m[2] : "" },
            content: "<p><b>" + escapeHtml(meta["標題"] || "") + "</b></p>" + main.html(),
            content_format: "html"
        });
    }

    let start = (current - 1) * PUSH_PAGE;
    let index = 0;
    pushes.forEach(function (el) {
        index++;
        if (index <= start || index > start + PUSH_PAGE) return;
        let tag = el.select(".push-tag").text().trim();
        let content = el.select(".push-content").text().replace(/^:\s*/, "");
        posts.push({
            id: "push" + index,
            floor: "#" + index,
            url: normalizeUrl(url),
            is_op: false,
            time: el.select(".push-ipdatetime").text().trim(),
            user: { name: el.select(".push-userid").text().trim() },
            content: "<p>" + (tag ? "<b>" + escapeHtml(tag) + "</b> " : "") + escapeHtml(content) + "</p>",
            content_format: "html"
        });
    });

    return Response.success({ posts: posts, page: current, total_pages: total },
        current < total ? String(current + 1) : "");
}
