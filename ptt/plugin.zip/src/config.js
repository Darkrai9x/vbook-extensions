let BASE_URL = "https://www.ptt.cc";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/$/, "");
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?ptt\.cc/i, BASE_URL);
}

function absUrl(href) {
    if (!href) return "";
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("http") === 0) return normalizeUrl(href);
    return BASE_URL + (href.indexOf("/") === 0 ? "" : "/") + href;
}

function escapeHtml(text) {
    return String(text || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// A board name or path -> "/bbs/<board>/index.html" (or the given older page)
function boardPath(input) {
    input = String(input || "");
    if (input.indexOf("/bbs/") === 0) return input;
    return "/bbs/" + input + "/index.html";
}

// Boards that ask the visitor to confirm they are over 18 are not supported: the extension never
// answers that question for the user.
function isAgeGate(response, doc) {
    return String(response.url || "").indexOf("/ask/over18") !== -1 || !doc.select("form[action*=over18]").isEmpty();
}
