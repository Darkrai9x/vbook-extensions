load('config.js');
// The hot boards (/bbs/hotboards.html), as board rows.
function execute() {
    let response = fetch(BASE_URL + "/bbs/hotboards.html");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let boards = response.html().select(".b-ent a.board").map(function (a) {
        let name = a.select(".board-name").text().trim();
        if (!name) return null;
        return {
            name: name,
            link: absUrl(a.attr("href")),
            description: a.select(".board-title").text().replace(/^[\s◎●]+/, "").trim(),
            threads: a.select(".board-nuser").text().trim() + " 人",
            posts: a.select(".board-class").text().trim(),
            action: { type: "list", name: name, script: "list.js", input: name }
        };
    }).filter(function (x) { return x; });
    if (boards.length === 0) return Response.error("Không tải được danh sách bản");
    return Response.success([{ id: "hot", title: "熱門看板", type: "board_list", items: boards }]);
}
