load('config.js');
// v2ex has no search for guests: its own box sends you to Sov2ex, whose JSON API this uses.
// `page` is the page number, "" on the first call.
const PAGE_SIZE = 20;
function execute(query, page) {
    query = (query || "").trim();
    if (!query) return Response.success([], "");
    let current = parseInt(page || "1") || 1;
    let response = fetch("https://www.sov2ex.com/api/search", {
        queries: { q: query, from: String((current - 1) * PAGE_SIZE), size: String(PAGE_SIZE) }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let json = response.json();
    let items = (json.hits || []).map(function (hit) {
        let src = hit._source || {};
        return {
            name: escapeHtml(String(src.title || "")),
            link: BASE_URL + "/t/" + src.id,
            description: String(src.content || "").replace(/\s+/g, " ").substring(0, 120),
            author: src.member || "",
            time: src.created ? epochOf(String(src.created)) : "",
            replies: String(src.replies === undefined ? "" : src.replies),
            board: src.node ? String(src.node) : ""
        };
    });
    let total = parseInt(json.total) || 0;
    return Response.success(items, current * PAGE_SIZE < total ? String(current + 1) : "");
}
