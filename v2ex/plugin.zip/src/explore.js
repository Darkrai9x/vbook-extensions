load('config.js');
// The node directory (/planes): one block of nodes per plane.
function execute() {
    let response = get(BASE_URL + "/planes");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let sections = [];
    response.html().select("#Main .box").forEach(function (box) {
        let nodes = box.select("a.item_node").map(function (a) {
            return {
                name: a.text(),
                link: absUrl(a.attr("href")),
                action: { type: "list", name: a.text(), script: "list.js", input: a.attr("href") }
            };
        });
        if (nodes.length === 0) return;
        let header = box.select(".header").first();
        let name = header ? header.text().replace(/\s+/g, " ").trim() : "";
        sections.push({ id: "plane_" + sections.length, title: name, type: "board_list", items: nodes });
    });
    if (sections.length === 0) return Response.error("Không tải được danh sách node");
    return Response.success(sections);
}
