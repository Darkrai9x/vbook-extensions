let BASE_URL = "https://www.v2ex.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

// v2ex serves a different, thinner page to a phone's user agent: always ask as a desktop browser
const DESKTOP_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";
function get(url) {
    return fetch(url, { headers: { "User-Agent": DESKTOP_UA } });
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absUrl(href) {
    if (!href) return "";
    if (href.indexOf("http") === 0) return normalizeUrl(href);
    return BASE_URL + (href.indexOf("/") === 0 ? "" : "/") + href;
}

// Avatars and images live on cdn.v2ex.com: keep absolute urls as they are
function assetUrl(src) {
    if (!src) return "";
    if (src.indexOf("//") === 0) return "https:" + src;
    return src.indexOf("http") === 0 ? src : absUrl(src);
}

// "/t/123#reply4" -> "https://www.v2ex.com/t/123"
function topicUrl(href) {
    return absUrl((href || "").replace(/[?#].*$/, ""));
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// The time of a v2ex row is its tooltip: "2026-11-23 22:22:43 +08:00". The app shows an epoch
// formatted for the device and a text as it is, so give it the epoch (seconds).
function timeOfSpan(span) {
    return epochOf(span ? (span.attr("title") || span.text()).trim() : "");
}

function epochOf(text) {
    let ms = Date.parse(text.replace(" ", "T").replace(" ", ""));
    return isNaN(ms) ? text : String(Math.round(ms / 1000));
}

// Topic rows of the home tabs, /recent and a node page
function parseTopics(doc, page, hasPages) {
    let items = doc.select(".cell.item, #TopicsNode > .cell").map(function (el) {
        let a = el.select(".item_title a").first();
        if (!a) return null;
        let info = el.select(".topic_info").first();
        let author = el.select(".topic_info strong a").first();
        let avatar = el.select("img.avatar").first();
        let node = el.select(".topic_info a.node").first();
        return {
            name: escapeHtml(a.text().trim()),
            link: topicUrl(a.attr("href")),
            author: author ? author.text() : "",
            avatar: avatar ? assetUrl(avatar.attr("src")) : "",
            time: timeOfSpan(el.select(".topic_info span[title]").first()),
            replies: el.select(".count_livid").text(),
            board: node ? node.text() : ""
        };
    }).filter(function (x) { return x; });

    // a pager exists on /recent and node pages: the page after the current one
    let next = doc.select("a.page_current + a.page_normal").first();
    return Response.success(items, hasPages && next ? String(parseInt(page || "1") + 1) : "");
}
