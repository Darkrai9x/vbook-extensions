load('config.js');
// One page of a topic: the topic itself first (page 1 only), then that page's replies.
// `page` is the page number, "" on the first call.
function execute(url, page) {
    url = normalizeUrl(url).replace(/[?#].*$/, "");
    page = page || "1";
    let response = get(page === "1" ? url : url + "?p=" + page);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    doc.select("script, noscript").remove();

    let posts = [];
    if (page === "1") {
        let header = doc.select("#Main .box .header").first();
        let author = header ? header.select("small.gray a").first() : null;
        let avatar = header ? header.select(".fr img.avatar").first() : null;
        let contents = doc.select("#Main .topic_content").map(function (el) { return fixHtml(el.html()); });
        posts.push({
            id: "topic",
            floor: "",
            url: url,
            is_op: true,
            time: timeOfSpan(header ? header.select("small.gray span[title]").first() : null),
            user: {
                name: author ? author.text() : "",
                avatar: avatar ? assetUrl(avatar.attr("src")) : "",
                link: author ? absUrl(author.attr("href")) : ""
            },
            content: (header ? "<p><b>" + escapeHtml(header.select("h1").text()) + "</b></p>" : "") + contents.join("<hr>"),
            content_format: "html"
        });
    }

    doc.select("div[id^=r_]").forEach(function (el) {
        let name = el.select("strong a.dark").first();
        let avatar = el.select("img.avatar").first();
        let body = el.select(".reply_content").first();
        let no = el.select(".no").text().trim();
        posts.push({
            id: el.attr("data-reply-id") || el.attr("id").replace("r_", ""),
            floor: no ? "#" + no : "",
            url: url + "#reply" + no,
            is_op: false,
            time: timeOfSpan(el.select(".ago").first()),
            user: {
                name: name ? name.text() : "",
                avatar: avatar ? assetUrl(avatar.attr("src")) : "",
                link: name ? absUrl(name.attr("href")) : ""
            },
            content: body ? fixHtml(body.html()) : "",
            content_format: "html"
        });
    });

    let totalPages = 1;
    doc.select(".ps_container .page_normal, .ps_container .page_current").forEach(function (a) {
        totalPages = Math.max(totalPages, parseInt(a.text()) || 1);
    });
    let current = parseInt(page);
    return Response.success({ posts: posts, page: current, total_pages: Math.max(totalPages, current) },
        current < totalPages ? String(current + 1) : "");
}

function fixHtml(html) {
    return html
        .replace(/(src|href)="\/\/(?!\/)/g, '$1="https://')
        .replace(/(src|href)="\/(?!\/)/g, '$1="' + BASE_URL + '/')
        .replace(/(?:<br\s*\/?>\s*){3,}/g, "<br><br>")
        .replace(/(?:\s*<br\s*\/?>)+\s*$/, "");
}
