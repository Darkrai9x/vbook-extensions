load('config.js');
// Topics of a home tab, /recent or a node. `page` is the page number, "" on the first call.
// The home tabs have no pages: only /recent and node pages show a pager.
function execute(input, page) {
    page = page || "1";
    let url = absUrl(input);
    if (page !== "1") url += (url.indexOf("?") === -1 ? "?" : "&") + "p=" + page;
    let response = get(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    return parseTopics(response.html(), page, url.indexOf("tab=") === -1);
}
