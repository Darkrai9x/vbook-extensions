load('config.js');
// The tabs of v2ex's home page, then the node directory.
function execute() {
    return Response.success([
        { title: "最热", input: "/?tab=hot", script: "list.js" },
        { title: "最新", input: "/recent", script: "list.js" },
        { title: "技术", input: "/?tab=tech", script: "list.js" },
        { title: "创意", input: "/?tab=creative", script: "list.js" },
        { title: "好玩", input: "/?tab=play", script: "list.js" },
        { title: "Apple", input: "/?tab=apple", script: "list.js" },
        { title: "酷工作", input: "/?tab=jobs", script: "list.js" },
        { title: "交易", input: "/?tab=deals", script: "list.js" },
        { title: "城市", input: "/?tab=city", script: "list.js" },
        { title: "问与答", input: "/?tab=qna", script: "list.js" },
        { title: "节点", input: "", script: "explore.js", type: "explore" }
    ]);
}
