function execute() {
    return Response.success([{
        title: "Tất cả thể loại",
        input: "http://www.nettruyenmoi.com/tim-truyen",
        script: "gen.js"
    }, {
        title: "Action",
        input: "http://www.nettruyenmoi.com/tim-truyen/action",
        script: "gen.js"
    }, {
        title: "Adult",
        input: "http://www.nettruyenmoi.com/tim-truyen/truong-thanh",
        script: "gen.js"
    }, {
        title: "Adventure",
        input: "http://www.nettruyenmoi.com/tim-truyen/adventure",
        script: "gen.js"
    }, {
        title: "Anime",
        input: "http://www.nettruyenmoi.com/tim-truyen/anime",
        script: "gen.js"
    }, {
        title: "Chuyển Sinh",
        input: "http://www.nettruyenmoi.com/tim-truyen/chuyen-sinh",
        script: "gen.js"
    }, {
        title: "Comedy",
        input: "http://www.nettruyenmoi.com/tim-truyen/comedy",
        script: "gen.js"
    }, {
        title: "Comic",
        input: "http://www.nettruyenmoi.com/tim-truyen/comic",
        script: "gen.js"
    }, {
        title: "Cooking",
        input: "http://www.nettruyenmoi.com/tim-truyen/cooking",
        script: "gen.js"
    }, {
        title: "Cổ Đại",
        input: "http://www.nettruyenmoi.com/tim-truyen/co-dai",
        script: "gen.js"
    }, {
        title: "Doujinshi",
        input: "http://www.nettruyenmoi.com/tim-truyen/doujinshi",
        script: "gen.js"
    }, {
        title: "Drama",
        input: "http://www.nettruyenmoi.com/tim-truyen/drama",
        script: "gen.js"
    }, {
        title: "Đam Mỹ",
        input: "http://www.nettruyenmoi.com/tim-truyen/dam-my",
        script: "gen.js"
    }, {
        title: "Ecchi",
        input: "http://www.nettruyenmoi.com/tim-truyen/ecchi",
        script: "gen.js"
    }, {
        title: "Fantasy",
        input: "http://www.nettruyenmoi.com/tim-truyen/fantasy",
        script: "gen.js"
    }, {
        title: "Gender Bender",
        input: "http://www.nettruyenmoi.com/tim-truyen/gender-bender",
        script: "gen.js"
    }, {
        title: "Harem",
        input: "http://www.nettruyenmoi.com/tim-truyen/harem",
        script: "gen.js"
    }, {
        title: "Historical",
        input: "http://www.nettruyenmoi.com/tim-truyen/historical",
        script: "gen.js"
    }, {
        title: "Horror",
        input: "http://www.nettruyenmoi.com/tim-truyen/horror",
        script: "gen.js"
    }, {
        title: "Josei",
        input: "http://www.nettruyenmoi.com/tim-truyen/josei",
        script: "gen.js"
    }, {
        title: "Live action",
        input: "http://www.nettruyenmoi.com/tim-truyen/live-action",
        script: "gen.js"
    }, {
        title: "Manga",
        input: "http://www.nettruyenmoi.com/tim-truyen/manga",
        script: "gen.js"
    }, {
        title: "Manhua",
        input: "http://www.nettruyenmoi.com/tim-truyen/manhua",
        script: "gen.js"
    }, {
        title: "Manhwa",
        input: "http://www.nettruyenmoi.com/tim-truyen/han-quoc-114",
        script: "gen.js"
    }, {
        title: "Martial Arts",
        input: "http://www.nettruyenmoi.com/tim-truyen/martial-arts",
        script: "gen.js"
    }, {
        title: "Mature",
        input: "http://www.nettruyenmoi.com/tim-truyen/mature",
        script: "gen.js"
    }, {
        title: "Mecha",
        input: "http://www.nettruyenmoi.com/tim-truyen/mecha-117",
        script: "gen.js"
    }, {
        title: "Mystery",
        input: "http://www.nettruyenmoi.com/tim-truyen/mystery",
        script: "gen.js"
    }, {
        title: "Ngôn Tình",
        input: "http://www.nettruyenmoi.com/tim-truyen/ngon-tinh",
        script: "gen.js"
    }, {
        title: "One shot",
        input: "http://www.nettruyenmoi.com/tim-truyen/one-shot",
        script: "gen.js"
    }, {
        title: "Psychological",
        input: "http://www.nettruyenmoi.com/tim-truyen/psychological",
        script: "gen.js"
    }, {
        title: "Romance",
        input: "http://www.nettruyenmoi.com/tim-truyen/romance",
        script: "gen.js"
    }, {
        title: "School Life",
        input: "http://www.nettruyenmoi.com/tim-truyen/school-life",
        script: "gen.js"
    }, {
        title: "Sci-fi",
        input: "http://www.nettruyenmoi.com/tim-truyen/sci-fi",
        script: "gen.js"
    }, {
        title: "Seinen",
        input: "http://www.nettruyenmoi.com/tim-truyen/seinen",
        script: "gen.js"
    }, {
        title: "Shoujo",
        input: "http://www.nettruyenmoi.com/tim-truyen/shoujo",
        script: "gen.js"
    }, {
        title: "Shoujo Ai",
        input: "http://www.nettruyenmoi.com/tim-truyen/shoujo-ai-126",
        script: "gen.js"
    }, {
        title: "Shounen",
        input: "http://www.nettruyenmoi.com/tim-truyen/shounen-127",
        script: "gen.js"
    }, {
        title: "Shounen Ai",
        input: "http://www.nettruyenmoi.com/tim-truyen/shounen-ai",
        script: "gen.js"
    }, {
        title: "Slice of Life",
        input: "http://www.nettruyenmoi.com/tim-truyen/slice-of-life",
        script: "gen.js"
    }, {
        title: "Smut",
        input: "http://www.nettruyenmoi.com/tim-truyen/smut",
        script: "gen.js"
    }, {
        title: "Soft Yaoi",
        input: "http://www.nettruyenmoi.com/tim-truyen/soft-yaoi",
        script: "gen.js"
    }, {
        title: "Soft Yuri",
        input: "http://www.nettruyenmoi.com/tim-truyen/soft-yuri",
        script: "gen.js"
    }, {
        title: "Sports",
        input: "http://www.nettruyenmoi.com/tim-truyen/sports",
        script: "gen.js"
    }, {
        title: "Supernatural",
        input: "http://www.nettruyenmoi.com/tim-truyen/supernatural",
        script: "gen.js"
    }, {
        title: "Tạp chí truyện tranh",
        input: "http://www.nettruyenmoi.com/tim-truyen/tap-chi-truyen-tranh",
        script: "gen.js"
    }, {
        title: "Thiếu Nhi",
        input: "http://www.nettruyenmoi.com/tim-truyen/thieu-nhi",
        script: "gen.js"
    }, {
        title: "Tragedy",
        input: "http://www.nettruyenmoi.com/tim-truyen/tragedy",
        script: "gen.js"
    }, {
        title: "Trinh Thám",
        input: "http://www.nettruyenmoi.com/tim-truyen/trinh-tham",
        script: "gen.js"
    }, {
        title: "Truyện scan",
        input: "http://www.nettruyenmoi.com/tim-truyen/truyen-scan",
        script: "gen.js"
    }, {
        title: "Truyện Màu",
        input: "http://www.nettruyenmoi.com/tim-truyen/truyen-mau",
        script: "gen.js"
    }, {
        title: "Việt Nam",
        input: "http://www.nettruyenmoi.com/tim-truyen/viet-nam",
        script: "gen.js"
    }, {
        title: "Webtoon",
        input: "http://www.nettruyenmoi.com/tim-truyen/webtoon",
        script: "gen.js"
    }, {
        title: "Xuyên Không",
        input: "http://www.nettruyenmoi.com/tim-truyen/xuyen-khong",
        script: "gen.js"
    }, {
        title: "16+",
        input: "http://www.nettruyenmoi.com/tim-truyen/16",
        script: "gen.js"
    }]);
}