function execute() {
    return Response.success([
        {title: "Mới cập nhật", script: "gen.js", input: "https://truyenyy.vip/truyen-moi-cap-nhat/"},
        {title: "Đọc nhiều", script: "gen.js", input: "https://truyenyy.vip/kim-thanh-bang/top/doc-nhieu-trong-tuan/"},
        {title: "Đề cử", script: "gen.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-de-cu/"},
        {title: "Bình luận nhiều", script: "gen.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-binh-luan-soi-noi/"}
    ]);
}


