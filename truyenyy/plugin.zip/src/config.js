let BASE_URL = "https://truyenyy.xyz";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}