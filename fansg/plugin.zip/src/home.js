function execute() {
    return Response.success([
        {title: "玄幻奇幻", input: "http://m.fansg.com/lists/book_42.html", script: "gen.js"},
        {title: "武侠修真", input: "http://m.fansg.com/lists/book_43.html", script: "gen.js"},
        {title: "都市异能", input: "http://m.fansg.com/lists/book_44.html", script: "gen.js"},
        {title: "历史军事", input: "http://m.fansg.com/lists/book_45.html", script: "gen.js"},
        {title: "网游竞技", input: "http://m.fansg.com/lists/book_46.html", script: "gen.js"},
        {title: "科幻灭世", input: "http://m.fansg.com/lists/book_47.html", script: "gen.js"},
        {title: "惊悚悬疑", input: "http://m.fansg.com/lists/book_49.html", script: "gen.js"},
        {title: "女生频道", input: "http://m.fansg.com/lists/book_48.html", script: "gen.js"},
        {title: "小说书库", input: "http://m.fansg.com/all.html", script: "gen.js"},
        {title: "小说排行", input: "http://m.fansg.com/lists/book_51.html", script: "gen.js"}
    ]);
}