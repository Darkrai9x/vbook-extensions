function execute() {
    return Response.success([
    {
      "title": "LOLICON (106K)",
      "input": "https://nhentai.net/tag/lolicon/",
      "script": "gen.js"
    },
    {
      "title": "STOCKINGS (106K)",
      "input": "https://nhentai.net/tag/stockings/",
      "script": "gen.js"
    },
    {
      "title": "BLOWJOB (95K)",
      "input": "https://nhentai.net/tag/blowjob/",
      "script": "gen.js"
    },
    {
      "title": "SCHOOLGIRL UNIFORM (86K)",
      "input": "https://nhentai.net/tag/schoolgirl-uniform/",
      "script": "gen.js"
    },
    {
      "title": "FULL COLOR (77K)",
      "input": "https://nhentai.net/tag/full-color/",
      "script": "gen.js"
    },
    {
      "title": "GLASSES (74K)",
      "input": "https://nhentai.net/tag/glasses/",
      "script": "gen.js"
    },
    {
      "title": "SHOTACON (63K)",
      "input": "https://nhentai.net/tag/shotacon/",
      "script": "gen.js"
    },
    {
      "title": "RAPE (60K)",
      "input": "https://nhentai.net/tag/rape/",
      "script": "gen.js"
    },
    {
      "title": "MOSAIC CENSORSHIP (59K)",
      "input": "https://nhentai.net/tag/mosaic-censorship/",
      "script": "gen.js"
    },
    {
      "title": "YAOI (58K)",
      "input": "https://nhentai.net/tag/yaoi/",
      "script": "gen.js"
    },
    {
      "title": "AHEGAO (56K)",
      "input": "https://nhentai.net/tag/ahegao/",
      "script": "gen.js"
    },
    {
      "title": "BONDAGE (55K)",
      "input": "https://nhentai.net/tag/bondage/",
      "script": "gen.js"
    },
    {
      "title": "MALES ONLY (50K)",
      "input": "https://nhentai.net/tag/males-only/",
      "script": "gen.js"
    },
    {
      "title": "MULTI-WORK SERIES (49K)",
      "input": "https://nhentai.net/tag/multi-work-series/",
      "script": "gen.js"
    },
    {
      "title": "INCEST (49K)",
      "input": "https://nhentai.net/tag/incest/",
      "script": "gen.js"
    },
    {
      "title": "MILF (47K)",
      "input": "https://nhentai.net/tag/milf/",
      "script": "gen.js"
    },
    {
      "title": "X-RAY (47K)",
      "input": "https://nhentai.net/tag/x-ray/",
      "script": "gen.js"
    },
    {
      "title": "DARK SKIN (45K)",
      "input": "https://nhentai.net/tag/dark-skin/",
      "script": "gen.js"
    },
    {
      "title": "PAIZURI (41K)",
      "input": "https://nhentai.net/tag/paizuri/",
      "script": "gen.js"
    },
    {
      "title": "SEX TOYS (39K)",
      "input": "https://nhentai.net/tag/sex-toys/",
      "script": "gen.js"
    },
    {
      "title": "FUTANARI (37K)",
      "input": "https://nhentai.net/tag/futanari/",
      "script": "gen.js"
    },
    {
      "title": "NETORARE (37K)",
      "input": "https://nhentai.net/tag/netorare/",
      "script": "gen.js"
    },
    {
      "title": "DOUBLE PENETRATION (37K)",
      "input": "https://nhentai.net/tag/double-penetration/",
      "script": "gen.js"
    },
    {
      "title": "DEFLORATION (36K)",
      "input": "https://nhentai.net/tag/defloration/",
      "script": "gen.js"
    },
    {
      "title": "TANKOUBON (36K)",
      "input": "https://nhentai.net/tag/tankoubon/",
      "script": "gen.js"
    },
    {
      "title": "TWINTAILS (34K)",
      "input": "https://nhentai.net/tag/twintails/",
      "script": "gen.js"
    },
    {
      "title": "FFM THREESOME (34K)",
      "input": "https://nhentai.net/tag/ffm-threesome/",
      "script": "gen.js"
    },
    {
      "title": "FULL CENSORSHIP (32K)",
      "input": "https://nhentai.net/tag/full-censorship/",
      "script": "gen.js"
    },
    {
      "title": "SWIMSUIT (32K)",
      "input": "https://nhentai.net/tag/swimsuit/",
      "script": "gen.js"
    },
    {
      "title": "YURI (32K)",
      "input": "https://nhentai.net/tag/yuri/",
      "script": "gen.js"
    },
    {
      "title": "FEMDOM (26K)",
      "input": "https://nhentai.net/tag/femdom/",
      "script": "gen.js"
    },
    {
      "title": "IMPREGNATION (31K)",
      "input": "https://nhentai.net/tag/impregnation/",
      "script": "gen.js"
    },
    {
      "title": "PONYTAIL (31K)",
      "input": "https://nhentai.net/tag/ponytail/",
      "script": "gen.js"
    },
    {
      "title": "COLLAR (30K)",
      "input": "https://nhentai.net/tag/collar/",
      "script": "gen.js"
    },
    {
      "title": "BIG PENIS (21K)",
      "input": "https://nhentai.net/tag/big-penis/",
      "script": "gen.js"
    },
    {
      "title": "DILF (29K)",
      "input": "https://nhentai.net/tag/dilf/",
      "script": "gen.js"
    },
    {
      "title": "HAIRY (27K)",
      "input": "https://nhentai.net/tag/hairy/",
      "script": "gen.js"
    },
    {
      "title": "KEMONOMIMI (27K)",
      "input": "https://nhentai.net/tag/kemonomimi/",
      "script": "gen.js"
    },
    {
      "title": "ANAL INTERCOURSE (26K)",
      "input": "https://nhentai.net/tag/anal-intercourse/",
      "script": "gen.js"
    },
    {
      "title": "CHEATING (25K)",
      "input": "https://nhentai.net/tag/cheating/",
      "script": "gen.js"
    },
    {
      "title": "PANTYHOSE (24K)",
      "input": "https://nhentai.net/tag/pantyhose/",
      "script": "gen.js"
    },
    {
      "title": "MUSCLE (24K)",
      "input": "https://nhentai.net/tag/muscle/",
      "script": "gen.js"
    },
    {
      "title": "BBM (24K)",
      "input": "https://nhentai.net/tag/bbm/",
      "script": "gen.js"
    },
    {
      "title": "KISSING (23K)",
      "input": "https://nhentai.net/tag/kissing/",
      "script": "gen.js"
    },
    {
      "title": "SISTER (22K)",
      "input": "https://nhentai.net/tag/sister/",
      "script": "gen.js"
    },
    {
      "title": "BIG ASS (22K)",
      "input": "https://nhentai.net/tag/big-ass/",
      "script": "gen.js"
    },
    {
      "title": "TENTACLES (22K)",
      "input": "https://nhentai.net/tag/tentacles/",
      "script": "gen.js"
    },
    {
      "title": "STORY ARC (22K)",
      "input": "https://nhentai.net/tag/story-arc/",
      "script": "gen.js"
    },
    {
      "title": "BIKINI (22K)",
      "input": "https://nhentai.net/tag/bikini/",
      "script": "gen.js"
    },
    {
      "title": "MASTURBATION (22K)",
      "input": "https://nhentai.net/tag/masturbation/",
      "script": "gen.js"
    },
    {
      "title": "UNCENSORED (21K)",
      "input": "https://nhentai.net/tag/uncensored/",
      "script": "gen.js"
    },
    {
      "title": "MIND CONTROL (21K)",
      "input": "https://nhentai.net/tag/mind-control/",
      "script": "gen.js"
    },
    {
      "title": "LACTATION (20K)",
      "input": "https://nhentai.net/tag/lactation/",
      "script": "gen.js"
    },
    {
      "title": "SWEATING (20K)",
      "input": "https://nhentai.net/tag/sweating/",
      "script": "gen.js"
    },
    {
      "title": "CROSSDRESSING (20K)",
      "input": "https://nhentai.net/tag/crossdressing/",
      "script": "gen.js"
    },
    {
      "title": "MIND BREAK (18K)",
      "input": "https://nhentai.net/tag/mind-break/",
      "script": "gen.js"
    },
    {
      "title": "TOMGIRL (19K)",
      "input": "https://nhentai.net/tag/tomgirl/",
      "script": "gen.js"
    },
    {
      "title": "MMF THREESOME (18K)",
      "input": "https://nhentai.net/tag/mmf-threesome/",
      "script": "gen.js"
    },
    {
      "title": "SCHOOLBOY UNIFORM (18K)",
      "input": "https://nhentai.net/tag/schoolboy-uniform/",
      "script": "gen.js"
    },
    {
      "title": "PREGNANT (18K)",
      "input": "https://nhentai.net/tag/pregnant/",
      "script": "gen.js"
    },
    {
      "title": "HUGE BREASTS (18K)",
      "input": "https://nhentai.net/tag/huge-breasts/",
      "script": "gen.js"
    },
    {
      "title": "EXHIBITIONISM (18K)",
      "input": "https://nhentai.net/tag/exhibitionism/",
      "script": "gen.js"
    },
    {
      "title": "FEMALES ONLY (17K)",
      "input": "https://nhentai.net/tag/females-only/",
      "script": "gen.js"
    },
    {
      "title": "UNUSUAL PUPILS (17K)",
      "input": "https://nhentai.net/tag/unusual-pupils/",
      "script": "gen.js"
    },
    {
      "title": "TEACHER (17K)",
      "input": "https://nhentai.net/tag/teacher/",
      "script": "gen.js"
    },
    {
      "title": "MAID (16K)",
      "input": "https://nhentai.net/tag/maid/",
      "script": "gen.js"
    },
    {
      "title": "FINGERING (16K)",
      "input": "https://nhentai.net/tag/fingering/",
      "script": "gen.js"
    },
    {
      "title": "GLOVES (16K)",
      "input": "https://nhentai.net/tag/gloves/",
      "script": "gen.js"
    },
    {
      "title": "HANDJOB (16K)",
      "input": "https://nhentai.net/tag/handjob/",
      "script": "gen.js"
    },
    {
      "title": "MOTHER (13K)",
      "input": "https://nhentai.net/tag/mother/",
      "script": "gen.js"
    },
    {
      "title": "BEAUTY MARK (15K)",
      "input": "https://nhentai.net/tag/beauty-mark/",
      "script": "gen.js"
    },
    {
      "title": "CONDOM (15K)",
      "input": "https://nhentai.net/tag/condom/",
      "script": "gen.js"
    },
    {
      "title": "LINGERIE (15K)",
      "input": "https://nhentai.net/tag/lingerie/",
      "script": "gen.js"
    },
    {
      "title": "GENDER BENDER (15K)",
      "input": "https://nhentai.net/tag/gender-bender/",
      "script": "gen.js"
    },
    {
      "title": "HAREM (14K)",
      "input": "https://nhentai.net/tag/harem/",
      "script": "gen.js"
    },
    {
      "title": "CUNNILINGUS (13K)",
      "input": "https://nhentai.net/tag/cunnilingus/",
      "script": "gen.js"
    },
    {
      "title": "URINATION (13K)",
      "input": "https://nhentai.net/tag/urination/",
      "script": "gen.js"
    },
    {
      "title": "VERY LONG HAIR (13K)",
      "input": "https://nhentai.net/tag/very-long-hair/",
      "script": "gen.js"
    },
    {
      "title": "FOOTJOB (13K)",
      "input": "https://nhentai.net/tag/footjob/",
      "script": "gen.js"
    },
    {
      "title": "TAIL (13K)",
      "input": "https://nhentai.net/tag/tail/",
      "script": "gen.js"
    },
    {
      "title": "HORNS (12K)",
      "input": "https://nhentai.net/tag/horns/",
      "script": "gen.js"
    },
    {
      "title": "PIERCING (12K)",
      "input": "https://nhentai.net/tag/piercing/",
      "script": "gen.js"
    },
    {
      "title": "CATGIRL (12K)",
      "input": "https://nhentai.net/tag/catgirl/",
      "script": "gen.js"
    },
    {
      "title": "SMALL BREASTS (12K)",
      "input": "https://nhentai.net/tag/small-breasts/",
      "script": "gen.js"
    },
    {
      "title": "GAG (11K)",
      "input": "https://nhentai.net/tag/gag/",
      "script": "gen.js"
    },
    {
      "title": "ANTHOLOGY (11K)",
      "input": "https://nhentai.net/tag/anthology/",
      "script": "gen.js"
    },
    {
      "title": "DRUGS (11K)",
      "input": "https://nhentai.net/tag/drugs/",
      "script": "gen.js"
    },
    {
      "title": "DEMON GIRL (11K)",
      "input": "https://nhentai.net/tag/demon-girl/",
      "script": "gen.js"
    },
    {
      "title": "BIG AREOLAE (11K)",
      "input": "https://nhentai.net/tag/big-areolae/",
      "script": "gen.js"
    },
    {
      "title": "PROSTITUTION (11K)",
      "input": "https://nhentai.net/tag/prostitution/",
      "script": "gen.js"
    },
    {
      "title": "GARTER BELT (11K)",
      "input": "https://nhentai.net/tag/garter belt/",
      "script": "gen.js"
    },
    {
      "title": "STOMACH DEFORMATION (11K)",
      "input": "https://nhentai.net/tag/stomach-deformation/",
      "script": "gen.js"
    },
    {
      "title": "FILMING (11K)",
      "input": "https://nhentai.net/tag/filming/",
      "script": "gen.js"
    },
    {
      "title": "ELF (11K)",
      "input": "https://nhentai.net/tag/elf/",
      "script": "gen.js"
    },
    {
      "title": "BUNNY GIRL (10K)",
      "input": "https://nhentai.net/tag/bunny-girl/",
      "script": "gen.js"
    },
    {
      "title": "EXTRANEOUS ADS (10K)",
      "input": "https://nhentai.net/tag/extraneous-ads/",
      "script": "gen.js"
    },
    {
      "title": "BALD (10K)",
      "input": "https://nhentai.net/tag/bald/",
      "script": "gen.js"
    },
    {
      "title": "BLINDFOLD (10K)",
      "input": "https://nhentai.net/tag/blindfold/",
      "script": "gen.js"
    },
    {
      "title": "BLACKMAIL (10K)",
      "input": "https://nhentai.net/tag/blackmail/",
      "script": "gen.js"
    },
    {
      "title": "GYARU (10K)",
      "input": "https://nhentai.net/tag/gyaru/",
      "script": "gen.js"
    },
    {
      "title": "SCAT (10K)",
      "input": "https://nhentai.net/tag/scat/",
      "script": "gen.js"
    },
    {
      "title": "TANLINES (9K)",
      "input": "https://nhentai.net/tag/tanlines/",
      "script": "gen.js"
    },
    {
      "title": "ROUGH TRANSLATION (9K)",
      "input": "https://nhentai.net/tag/rough-translation/",
      "script": "gen.js"
    },
    {
      "title": "KIMONO (9K)",
      "input": "https://nhentai.net/tag/kimono/",
      "script": "gen.js"
    },
    {
      "title": "VIRGINITY (9K)",
      "input": "https://nhentai.net/tag/virginity/",
      "script": "gen.js"
    },
    {
      "title": "SQUIRTING (9K)",
      "input": "https://nhentai.net/tag/squirting/",
      "script": "gen.js"
    },
    {
      "title": "BUKKAKE (9K)",
      "input": "https://nhentai.net/tag/bukkake/",
      "script": "gen.js"
    },
    {
      "title": "BBW (9K)",
      "input": "https://nhentai.net/tag/bbw/",
      "script": "gen.js"
    },
    {
      "title": "HALO (8K)",
      "input": "https://nhentai.net/tag/halo/",
      "script": "gen.js"
    },
    {
      "title": "INFLATION (8K)",
      "input": "https://nhentai.net/tag/inflation/",
      "script": "gen.js"
    },
    {
      "title": "RIMJOB (8K)",
      "input": "https://nhentai.net/tag/rimjob/",
      "script": "gen.js"
    },
    {
      "title": "SOLE DICKGIRL (8K)",
      "input": "https://nhentai.net/tag/sole-dickgirl/",
      "script": "gen.js"
    },
    {
      "title": "NO PENETRATION (8K)",
      "input": "https://nhentai.net/tag/no-penetration/",
      "script": "gen.js"
    },
    {
      "title": "SLEEPING (8K)",
      "input": "https://nhentai.net/tag/sleeping/",
      "script": "gen.js"
    }
  ]);
}