function execute() {
    return Response.success([
    {
      "title": "🏠 New uploads",
      "input": "https://nhentai.net",
      "script": "gen.js"
    },
    {
      "title": "BIG BREASTS (210K)",
      "input": "https://nhentai.net/tag/big-breasts/",
      "script": "gen.js"
    },
    {
      "title": "SOLE FEMALE (181K)",
      "input": "https://nhentai.net/tag/sole-female/",
      "script": "gen.js"
    },
    {
      "title": "SOLE MALE (162K)",
      "input": "https://nhentai.net/tag/sole-male/",
      "script": "gen.js"
    },
    {
      "title": "GROUP (116K)",
      "input": "https://nhentai.net/tag/group/",
      "script": "gen.js"
    },
    {
      "title": "ANAL (114K)",
      "input": "https://nhentai.net/tag/anal/",
      "script": "gen.js"
    },
    {
      "title": "NAKADASHI (108K)",
      "input": "https://nhentai.net/tag/nakadashi/",
      "script": "gen.js"
    }
  ]);
}