function execute() {
    return Response.success([
        { title: "Truyện Teen", input: "http://santruyen.com/truyen-teen/", script: "gen.js" },
        { title: "Tiểu Thuyết", input: "http://santruyen.com/tieu-thuyet/", script: "gen.js" },
        { title: "Truyện gay", input: "http://santruyen.com/truyen-gay/", script: "gen.js" },
        { title: "Truyện Tình Cảm", input: "http://santruyen.com/truyen-tinh-cam/", script: "gen.js" },
        { title: "Truyện Kiếm Hiệp", input: "http://santruyen.com/truyen-kiem-hiep/", script: "gen.js" },
        { title: "Truyện Ma", input: "http://santruyen.com/truyen-ma/", script: "gen.js" },
        { title: "Đô Thị", input: "http://santruyen.com/do-thi/", script: "gen.js" },
        { title: "Tiên Hiệp", input: "http://santruyen.com/tien-hiep/", script: "gen.js" },
        { title: "Ngôn Tình", input: "http://santruyen.com/ngon-tinh/", script: "gen.js" },
        { title: "Võng Du", input: "http://santruyen.com/vong-du/", script: "gen.js" },
        { title: "Quân Sự", input: "http://santruyen.com/quan-su/", script: "gen.js" },
        { title: "Dị giới", input: "http://santruyen.com/di-gioi/", script: "gen.js" },
        { title: "Huyền Huyễn", input: "http://santruyen.com/huyen-huyen/", script: "gen.js" },
        { title: "Khoa Huyễn", input: "http://santruyen.com/khoa-huyen/", script: "gen.js" },
        { title: "Lịch sử", input: "http://santruyen.com/lich-su/", script: "gen.js" },
        { title: "Tổng hợp", input: "http://santruyen.com/tong-hop/", script: "gen.js" },
        { title: "Trinh Thám", input: "http://santruyen.com/trinh-tham/", script: "gen.js" },
        { title: "Đam Mỹ", input: "http://santruyen.com/dam-my/", script: "gen.js" },
        { title: "Xuyên Không", input: "http://santruyen.com/xuyen-khong/", script: "gen.js" },
        { title: "Truyện kinh dị", input: "http://santruyen.com/truyen-kinh-di/", script: "gen.js" },
        { title: "Bách hợp", input: "http://santruyen.com/bach-hop/", script: "gen.js" }
    ]);
}