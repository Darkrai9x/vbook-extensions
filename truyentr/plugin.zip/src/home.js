function execute() {
    return Response.success([
        {title: "Truyện mới cập nhật", input: "truyen-moi-cap-nhat", script: "gen1.js"},
        {title: "Ngôn Tình Hay", input: "ngon-tinh-hay", script: "gen1.js"},
        {title: "Truyện Full", input: "truyen-full", script: "gen1.js"},
        {title: "Truyện Teen Hay", input: "truyen-teen-hay", script: "gen1.js"},
        {title: "Truyện Hot", input: "truyen-hot", script: "gen1.js"},
        {title: "Kiếm Hiệp Hay", input: "kiem-hiep-hay", script: "gen1.js"},
    ]);
}
