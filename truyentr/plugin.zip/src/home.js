function execute() {
    return Response.success([
        {title: "Truyện mới cập nhật", input: "https://truyentr.org/danh-sach/truyen-moi/", script: "gen.js"},
        {title: "Truyện Hot", input: "https://truyentr.org/danh-sach/truyen-hot/", script: "gen.js"},
        {title: "Truyện Full", input: "https://truyentr.org/danh-sach/truyen-full/", script: "gen.js"},
        {title: "FanFic Hay NEW", input: "https://truyentr.org/danh-sach/fanfic-hay/", script: "gen.js"},
        {title: "Tiên Hiệp Hay", input: "https://truyentr.org/danh-sach/tien-hiep-hay/", script: "gen.js"},
        {title: "Kiếm Hiệp Hay", input: "https://truyentr.org/danh-sach/kiem-hiep-hay/", script: "gen.js"},
        {title: "Truyện Teen Hay", input: "https://truyentr.org/danh-sach/truyen-teen-hay/", script: "gen.js"},
        {title: "Ngôn Tình Hay", input: "https://truyentr.org/danh-sach/ngon-tinh-hay/", script: "gen.js"},
        {title: "Ngôn Tình Sắc", input: "https://truyentr.org/danh-sach/ngon-tinh-sac/", script: "gen.js"},
        {title: "Ngôn Tình Ngược", input: "https://truyentr.org/danh-sach/ngon-tinh-nguoc/", script: "gen.js"},
        {title: "Ngôn Tình Sủng", input: "https://truyentr.org/danh-sach/ngon-tinh-sung/", script: "gen.js"},
        {title: "Ngôn Tình Hài", input: "https://truyentr.org/danh-sach/ngon-tinh-hai/", script: "gen.js"},
        {title: "Đam Mỹ Hài", input: "https://truyentr.org/danh-sach/dam-my-hai/", script: "gen.js"},
        {title: "Đam Mỹ Hay", input: "https://truyentr.org/danh-sach/dam-my-hay/", script: "gen.js"},
        {title: "Đam Mỹ Sắc", input: "https://truyentr.org/danh-sach/dam-my-sac/", script: "gen.js"}
    ]);
}
