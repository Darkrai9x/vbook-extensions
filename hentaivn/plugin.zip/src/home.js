function execute() {
    return Response.success([
        {title: "Truyện mới", input: "https://hentaivn.moe/danh-sach.html", script: "gen.js"},
        {title: "Chương mới", input: "https://hentaivn.moe/chap-moi.html", script: "gen.js"},
        {title: "Full màu", input: "https://hentaivn.moe/the-loai-37-full_color.html", script: "gen.js"},
        {title: "Không che", input: "https://hentaivn.moe/the-loai-99-khong_che.html", script: "gen.js"}
    ]);
}