let BASE_URL = 'https://hentaivn.tv';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}