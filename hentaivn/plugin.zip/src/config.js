let BASE_URL = 'https://hentaivn.zone';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}