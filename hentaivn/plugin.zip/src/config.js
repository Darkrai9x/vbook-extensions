let BASE_URL = 'https://hentaivn.icu';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}