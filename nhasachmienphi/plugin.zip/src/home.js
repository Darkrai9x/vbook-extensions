function execute() {
    return Response.success([
    {title: "Tất Cả Sách", input: "https://nhasachmienphi.com/tat-ca-sach",script: "gen.js"},
  {title: "Góc Review", input: "https://nhasachmienphi.com/blogs", script: "gen.js"}
    ]);
}