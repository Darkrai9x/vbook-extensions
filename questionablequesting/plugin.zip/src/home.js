load('config.js');
function execute() {
    return Response.success([
        { title: "Forums", input: "", script: "explore.js", type: "explore" },
        { title: "Latest posts", input: "/whats-new/posts/", script: "list.js" }
    ]);
}
