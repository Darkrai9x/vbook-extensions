let BASE_URL = "https://forum.questionablequesting.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// "/threads/slug.123/" -> absolute url on BASE_URL
function absUrl(href) {
    if (!href) return "";
    if (href.indexOf("http") === 0) return normalizeUrl(href);
    return BASE_URL + (href.indexOf("/") === 0 ? "" : "/") + href;
}

// Images may live on another host (img.otofun.net): keep absolute urls as they are
function assetUrl(src) {
    if (!src) return "";
    if (src.indexOf("//") === 0) return "https:" + src;
    return src.indexOf("http") === 0 ? src : absUrl(src);
}

// XenForo time element when there is one (thread lists), else the element's own text
function timeOf(el) {
    let t = el.select("time").first();
    if (!t) return el.text().trim();
    return t.attr("data-time") || t.attr("data-timestamp") || t.text();
}

// The verified-account badge is an inline svg whose <title> would end up in the name
function cleanNames(doc) {
    doc.select(".username svg, .message-name svg").remove();
}

// Boards listed on the forum index: [{ id, name, href, threads, posts }]
function loadBoards() {
    let response = fetch(BASE_URL + "/forums/");
    if (!response.ok) return null;
    return response.html().select(".node--forum").map(function (el) {
        let a = el.select(".node-title a").first();
        let stats = el.select(".node-statsMeta dd");
        let href = a.attr("href");
        let m = href.match(/\.(\d+)\/?$/);
        return {
            id: m ? m[1] : href,
            name: a.text(),
            href: href,
            threads: stats.size() > 0 ? stats.get(0).text() : "",
            posts: stats.size() > 1 ? stats.get(1).text() : ""
        };
    });
}

function parseThreads(doc) {
    cleanNames(doc);

    let items = doc.select(".structItem--thread").map(function (el) {
        let a = el.select(".structItem-title a[href*=/threads/]").last();
        if (!a) return null;
        let meta = el.select(".structItem-cell--meta dd");
        let latest = el.select(".structItem-cell--latest .username").first();
        return {
            // html: the thread's prefix labels as <tag>, then the title
            name: tagsOf(el) + escapeHtml(a.text().trim()),
            link: absUrl(a.attr("href")),
            author: el.select(".structItem-parts .username").first() ? el.select(".structItem-parts .username").first().text() : "",
            avatar: el.select(".structItem-cell--icon .avatar img").first() ? el.select(".structItem-cell--icon .avatar img").first().attr("src") : "",
            time: timeOf(el.select(".structItem-startDate").first() || el),
            replies: meta.size() > 0 ? meta.get(0).text() : "",
            views: meta.size() > 1 ? meta.get(1).text() : "",
            board: el.select(".structItem-parts a[href*=/forums/]").text(),
            last_post: latest ? { user: latest.text(), time: timeOf(el.select(".structItem-cell--latest").first()) } : null,
            pinned: !el.select(".structItem-status--sticky").isEmpty(),
            locked: !el.select(".structItem-status--locked").isEmpty()
        };
    }).filter(function (x) { return x; });

    let next = doc.select("a.pageNav-jump--next").attr("href");
    return Response.success(items, next || "");
}

// otofun's own label colors: [fill, text] by the `label--<name>` class of a thread prefix
const LABEL_COLORS = {
    primary: ["#ebf1f9", "#23497b"],
    accent: ["#ffe0cc", "#ff6600"],
    orange: ["#ffcc00", "#000000"],
    red: ["#e00000", "#ffffff"],
    green: ["#008000", "#ffffff"],
    royalBlue: ["#4169e1", "#ffffff"],
    olive: ["#808000", "#ffffff"],
    gray: ["#808080", "#ffffff"]
};

// The prefixes of a thread as `<tag bg="…" color="…">text</tag> `, one per label
function tagsOf(el) {
    return el.select(".structItem-title .labelLink > span").map(function (label) {
        let m = (label.attr("class") || "").match(/(?:label--|prefix_)(\w+)/);
        let c = m ? LABEL_COLORS[m[1]] : null;
        return "<tag" + (c ? ' bg="' + c[0] + '" color="' + c[1] + '"' : "") + ">" + escapeHtml(label.text().trim()) + "</tag> ";
    }).join("");
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Search results are rows of a different markup than the board lists
function parseSearch(doc) {
    cleanNames(doc);
    let items = doc.select("li.block-row .contentRow").map(function (el) {
        let a = el.select(".contentRow-title a[href*=/threads/]").first();
        if (!a) return null;
        let minor = el.select(".contentRow-minor li");
        let replies = "";
        minor.forEach(function (li) {
            let m = li.text().match(/^(?:Trả lời|Replies):\s*(.+)$/);
            if (m) replies = m[1];
        });
        let author = el.select(".contentRow-minor .username").first();
        let avatar = el.select(".contentRow-figure img").first();
        let board = el.select(".contentRow-minor a[href*=/forums/]").first();
        return {
            name: escapeHtml(a.text().replace(/\u00a0/g, " ").trim()),
            link: absUrl(a.attr("href")),
            description: el.select(".contentRow-snippet").text(),
            author: author ? author.text() : "",
            avatar: avatar ? assetUrl(avatar.attr("src")) : "",
            time: timeOf(el.select(".contentRow-minor time").first() ? el.select(".contentRow-minor") : el),
            replies: replies,
            board: board ? board.text() : ""
        };
    }).filter(function (x) { return x; });
    return Response.success(items, doc.select("a.pageNav-jump--next").attr("href") || "");
}
