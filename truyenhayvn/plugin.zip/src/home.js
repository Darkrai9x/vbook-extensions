function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "", script: "gen.js" },
        { title: "Hôn nhân", input: "8", script: "gen.js" },
        { title: "Mẹ đơn thân", input: "14", script: "gen.js" },
        { title: "Cuộc sống", input: "3", script: "gen.js" }
    ]);
}
