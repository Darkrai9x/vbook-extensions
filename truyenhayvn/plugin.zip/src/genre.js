load('config.js');
function execute() {
    let response = fetch(API_URL + "/categories", {
        queries: { per_page: "100", _fields: "id,name,slug,count" }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    let genres = [];
    (response.json() || []).forEach(function (e) {
        if (!e.count || e.slug === "uncategorized") return;
        genres.push({ title: decodeHtml(e.name), input: String(e.id), script: "gen.js" });
    });
    return Response.success(genres);
}
