load('config.js');
function execute(input, page) {
    input = input || "";
    page = page || "1";

    let queries = { per_page: "100", page: page };
    if (input) {
        let category = input;
        if (!/^\d+$/.test(category)) {
            let lookup = fetch(API_URL + "/categories", { queries: { slug: category, _fields: "id" } });
            if (!lookup.ok) return Response.error("HTTP " + lookup.status);
            let found = lookup.json();
            if (!found || !found.length) return Response.error("Không tìm thấy chuyên mục");
            category = String(found[0].id);
        }
        queries.categories = category;
    }

    let response = fetchPosts(queries);
    if (!response.ok) return Response.error("HTTP " + response.status);

    return Response.success(groupPosts(response.json()), nextToken(response, page));
}
