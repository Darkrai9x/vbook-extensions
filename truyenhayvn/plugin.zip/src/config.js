let BASE_URL = "https://truyenhay.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

let API_URL = BASE_URL + "/wp-json/wp/v2";
let LIST_FIELDS = "id,link,title,excerpt,date,_links,_embedded";

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// The site swaps Latin letters for look-alike IPA/Cyrillic glyphs in post text.
let GLYPHS = { "ɡ": "g", "ɠ": "g", "ѕ": "s", "Ѕ": "S", "г": "r", "ɾ": "r", "һ": "h", "ɦ": "h", "ҡ": "k" };
function fixText(text) {
    return String(text || "").replace(/[ɡɠѕЅгɾһɦҡ]/g, function (ch) {
        return GLYPHS[ch];
    });
}

function decodeHtml(text) {
    return Html.parse(String(text || "")).text();
}

function cleanTitle(text) {
    return fixText(decodeHtml(text)).replace(/\s+/g, " ").trim();
}

// Each WordPress post is one chapter. Serial stories share a title prefix such as
// "Tên truyện: Chương 12", "Tên truyện chương 12", "Tên truyện phần 12" or "Tên truyện 12".
function parseTitle(title) {
    title = cleanTitle(title);
    let match = /^(.+?)[\s:,.\-–]*(?:(?:chương|phần|tập|kỳ|chap)\s*)?(\d+)$/i.exec(title);
    if (match && match[1].trim().length > 1) {
        return { series: match[1].trim(), number: parseInt(match[2]), title: title };
    }
    return { series: title, number: 0, title: title };
}

function seriesKey(text) {
    return String(text || "").toLowerCase().replace(/\s+/g, " ").trim();
}

function chapterName(info) {
    if (!info.number) return info.title;
    let rest = info.title.substring(info.series.length).replace(/^[\s:,.\-–]+/, "");
    return /^\d+$/.test(rest) ? "Chương " + rest : rest;
}

function postSlug(url) {
    let match = /\/([^\/?#]+)\.html/.exec(url);
    return match ? match[1] : "";
}

function postCover(post) {
    let media = post._embedded && post._embedded["wp:featuredmedia"];
    return media && media[0] && media[0].source_url ? media[0].source_url : "";
}

// Lists show one entry per story: chapters of the same story on a page are merged.
function groupPosts(posts) {
    let items = [];
    let seen = {};
    (posts || []).forEach(function (post) {
        let info = parseTitle(post.title.rendered);
        let key = seriesKey(info.series);
        if (!info.series || seen[key]) return;
        seen[key] = true;
        items.push({
            name: info.series,
            link: post.link,
            cover: postCover(post),
            description: info.number ? "Mới: " + chapterName(info) : cleanTitle(post.excerpt.rendered).substring(0, 160),
            tag: info.number ? "Nhiều kỳ" : ""
        });
    });
    return items;
}

function fetchPosts(queries) {
    queries._fields = LIST_FIELDS;
    queries._embed = "wp:featuredmedia";
    return fetch(API_URL + "/posts", { queries: queries });
}

function nextToken(response, page) {
    let current = parseInt(page) || 1;
    let total = parseInt(response.header("x-wp-totalpages")) || 0;
    return current < total ? String(current + 1) : "";
}
