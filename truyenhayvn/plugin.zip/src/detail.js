load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let heading = doc.select("article h1.entry-title").text();
    if (!heading) return Response.error("Không tìm thấy truyện");
    let info = parseTitle(heading);

    let content = doc.select("article div.entry-content[itemprop=text]").first();
    let author = "";
    if (content) {
        let match = /Tác giả\s*:\s*([^<\n]+)/.exec(fixText(content.select("p").first() ? content.select("p").first().html() : ""));
        if (match) author = decodeHtml(match[1]).trim();
    }

    let tags = doc.select(".entry-categories a").map(function (e) {
        let slug = e.attr("href").replace(/\/+$/, "").split("/").pop();
        return { title: e.text(), input: slug, script: "gen.js" };
    });

    let details = [];
    if (info.number) details.push("Chương đang xem: " + chapterName(info));
    details.push("Chuyên mục: " + doc.select(".entry-categories a").text());
    details.push("Ngày đăng: " + doc.select("time.entry-time").text());

    return Response.success({
        name: info.series,
        author: author || doc.select(".entry-author-name").text(),
        cover: doc.select("meta[property=og:image]").attr("content"),
        description: fixText(doc.select("meta[name=description]").attr("content")),
        detail: details.join("<br>"),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: info.number > 0,
        tags: tags
    });
}
