load('config.js');
function execute(query, page) {
    query = query || "";
    page = page || "1";

    let response = fetchPosts({
        search: query,
        search_columns: "post_title",
        per_page: "100",
        page: page
    });
    if (!response.ok) return Response.error("HTTP " + response.status);

    return Response.success(groupPosts(response.json()), nextToken(response, page));
}
