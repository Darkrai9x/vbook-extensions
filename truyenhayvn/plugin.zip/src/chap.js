load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let content = doc.select("article div.entry-content[itemprop=text]").first();
    if (!content) return Response.error("Không tìm thấy nội dung chương");
    content.select("script, style, noscript, iframe, ins, .related, .sharedaddy").remove();

    return Response.success(fixText(content.html()), fixText(doc.select("article h1.entry-title").text()));
}
