load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    let slug = postSlug(url);
    if (!slug) return Response.error("URL truyện không hợp lệ");

    let response = fetch(API_URL + "/posts", {
        queries: { slug: slug, _fields: "id,link,title,date" }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let found = response.json();
    if (!found || !found.length) return Response.error("Không tìm thấy bài viết");
    let current = found[0];
    let info = parseTitle(current.title.rendered);
    let key = seriesKey(info.series);

    let posts = [];
    let hasCurrent = false;
    let page = 1;
    let total = 1;
    do {
        let list = fetch(API_URL + "/posts", {
            queries: {
                search: info.series,
                search_columns: "post_title",
                orderby: "date",
                order: "asc",
                per_page: "100",
                page: String(page),
                _fields: "id,link,title"
            }
        });
        if (!list.ok) break;
        total = parseInt(list.header("x-wp-totalpages")) || 1;
        (list.json() || []).forEach(function (post) {
            let item = parseTitle(post.title.rendered);
            if (seriesKey(item.series) !== key) return;
            if (post.id === current.id) hasCurrent = true;
            posts.push({ info: item, link: post.link, index: posts.length });
        });
        page++;
    } while (page <= total && page <= 30);

    if (!hasCurrent) {
        posts.push({ info: info, link: current.link, index: posts.length });
    }
    posts.sort(function (a, b) {
        return a.info.number - b.info.number || a.index - b.index;
    });

    let chapters = posts.map(function (post) {
        return {
            name: chapterName(post.info),
            url: post.link,
            lock: false,
            pay: false
        };
    });
    return Response.success(chapters);
}
