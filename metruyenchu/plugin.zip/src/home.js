function execute() {
    return Response.success([
        {title: "Thịnh hành", script: "gen.js", input: "https://metruyenchu.com/bang-xep-hang/tuan/thinh-hanh"},
        {title: "Đọc nhiều", script: "rank.js", input: "https://metruyenchu.com/bang-xep-hang/tuan/doc-nhieu"},
        {title: "Tặng thưởng", script: "rank.js", input: "https://metruyenchu.com/bang-xep-hang/tuan/tang-thuong"},
        {title: "Đề cử", script: "rank.js", input: "https://metruyenchu.com/bang-xep-hang/tuan/de-cu"},
        {title: "Yêu thích", script: "rank.js", input: "https://metruyenchu.com/bang-xep-hang/tuan/yeu-thich"},
        {title: "Thảo luận", script: "rank.js", input: "https://metruyenchu.com/bang-xep-hang/tuan/thao-luan"}
    ]);
}
