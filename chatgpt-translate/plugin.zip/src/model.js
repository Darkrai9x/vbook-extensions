function execute() {
    return Response.success([
        { id: "gpt-6-luna", name: "GPT-6 Luna", description: "Mặc định; nhanh và rẻ nhất thế hệ GPT-6, hợp cho dịch số lượng lớn", isNetworkRequired: true },
        { id: "gpt-6.1-sol", name: "GPT-6.1 Sol", description: "Gần bằng Astra với chi phí thấp hơn", isNetworkRequired: true },
        { id: "gpt-6.1-terra", name: "GPT-6.1 Terra", description: "Nhanh, cân bằng giữa Luna và Sol", isNetworkRequired: true },
        { id: "gpt-6-astra", name: "GPT-6 Astra", description: "Mạnh nhất; chậm và đắt", isNetworkRequired: true },
        { id: "gpt-5.5", name: "GPT-5.5", description: "Thế hệ GPT-5 mới nhất, chất lượng cao", isNetworkRequired: true },
        { id: "gpt-5.4", name: "GPT-5.4", description: "GPT-5 chất lượng cao, đời trước", isNetworkRequired: true },
        { id: "gpt-5.4-mini", name: "GPT-5.4 mini", description: "Nhanh, rẻ, cân bằng chất lượng", isNetworkRequired: true },
        { id: "gpt-5.2", name: "GPT-5.2", description: "GPT-5 đời trước", isNetworkRequired: true },
        { id: "gpt-5", name: "GPT-5", description: "Ngừng 11/12/2026; nên chuyển sang GPT-6", isNetworkRequired: true },
        { id: "gpt-5-mini", name: "GPT-5 mini", description: "Ngừng 11/12/2026; nên chuyển sang GPT-6", isNetworkRequired: true },
        { id: "gpt-5-nano", name: "GPT-5 nano", description: "Ngừng 11/12/2026; nên chuyển sang GPT-6 Luna", isNetworkRequired: true },
        { id: "gpt-4.1", name: "GPT-4.1", description: "Không suy luận, ngừng 14/1/2027; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "gpt-4.1-mini", name: "GPT-4.1 mini", description: "Không suy luận, ngừng 14/1/2027; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "gpt-4o", name: "GPT-4o", description: "Đời cũ, ngừng 14/1/2027; hỗ trợ Temperature", isNetworkRequired: true },
        { id: "gpt-4o-mini", name: "GPT-4o mini", description: "Đời cũ, ngừng 14/1/2027; hỗ trợ Temperature", isNetworkRequired: true }
    ]);
}
