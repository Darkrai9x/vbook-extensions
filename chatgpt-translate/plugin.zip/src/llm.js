var LLM_NAME = "ChatGPT";
var LLM_ENDPOINT = "https://api.openai.com/v1/chat/completions";
var LLM_DEFAULT_MODEL = "gpt-6-luna";
var LLM_ANALYSIS_MODEL = "gpt-6-luna";
var LLM_SUPPORTS_TEMPERATURE = true;
var LLM_TEMPERATURE_NOTE = "; chỉ áp dụng cho GPT-4.1 và GPT-4o (model suy luận không hỗ trợ)";
var LLM_ROTATE_KEY_STATUSES = { 401: true, 403: true, 429: true };
// minEffort: lowest reasoning_effort the model accepts; null = non-reasoning model (takes temperature).
var LLM_MODEL_INFO = {
    "gpt-6-luna": { minEffort: "none" },
    "gpt-6.1-sol": { minEffort: "low" },
    "gpt-6-astra": { minEffort: "low" },
    "gpt-5.5": { minEffort: "none" },
    "gpt-5.4": { minEffort: "none" },
    "gpt-5.4-mini": { minEffort: "none" },
    "gpt-5.2": { minEffort: "none" },
    "gpt-5": { minEffort: "minimal" },
    "gpt-5-mini": { minEffort: "minimal" },
    "gpt-5-nano": { minEffort: "minimal" },
    "gpt-4.1": { minEffort: null },
    "gpt-4.1-mini": { minEffort: null },
    "gpt-4o": { minEffort: null },
    "gpt-4o-mini": { minEffort: null }
};

function llmAddProviderConfig(config) {
    config[translationConfigKey("reasoning_effort")] = {
        title: "Mức suy luận (reasoning effort)",
        subtitle: "auto: mức thấp nhất model hỗ trợ (nhanh, rẻ). Mức cao dịch kỹ hơn nhưng chậm và tốn token hơn; không áp dụng cho GPT-4.1/GPT-4o",
        default: "auto",
        values: ["auto", "none", "low", "medium", "high"],
        mode: "select",
        format: "single"
    };
}

function llmNormalizeModel(model) {
    var selected = String(model || "").trim();
    return LLM_MODEL_INFO[selected] ? selected : LLM_DEFAULT_MODEL;
}

function llmReasoningEffort(minEffort) {
    var effort = "auto";
    try {
        effort = String(localConfig.getItem(translationConfigKey("reasoning_effort")) || "auto");
    } catch (e) {}
    if (effort === "low" || effort === "medium" || effort === "high") return effort;
    return minEffort;
}

// options: { temperature, maxTokens, json }
function llmBuildBody(model, systemPrompt, userText, options) {
    options = options || {};
    model = llmNormalizeModel(model);
    var minEffort = LLM_MODEL_INFO[model].minEffort;
    var body = {
        model: model,
        messages: [
            { role: "developer", content: systemPrompt },
            { role: "user", content: userText }
        ],
        max_completion_tokens: options.maxTokens || 4096
    };
    if (minEffort) {
        body.reasoning_effort = llmReasoningEffort(minEffort);
    } else if (options.temperature !== undefined) {
        body.temperature = options.temperature;
    }
    if (options.json) body.response_format = { type: "json_object" };
    return body;
}

// Tries each key in order; rotates on auth/quota errors. Returns { text, finishReason, error, keyIndex }.
function llmRequest(apiKeys, body, timeout) {
    var payload = JSON.stringify(body);
    var lastError = "";
    for (var keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        var response;
        try {
            response = fetch(LLM_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apiKeys[keyIndex]
                },
                body: payload,
                timeout: timeout || 120000
            });
        } catch (e) {
            lastError = LLM_NAME + ": " + String(e);
            continue;
        }

        if (!response.ok) {
            lastError = llmApiError(response);
            if (LLM_ROTATE_KEY_STATUSES[response.status]) continue;
            return { text: "", finishReason: "", error: lastError, keyIndex: keyIndex };
        }

        var data;
        try {
            data = JSON.parse(response.text());
        } catch (e2) {
            return { text: "", finishReason: "", error: LLM_NAME + " trả về dữ liệu không hợp lệ", keyIndex: keyIndex };
        }

        var choice = data && data.choices && data.choices.length > 0 ? data.choices[0] : null;
        var message = choice && choice.message ? choice.message : null;
        var finishReason = choice && choice.finish_reason ? String(choice.finish_reason) : "";
        if (message && message.refusal && !message.content) finishReason = "refusal: " + String(message.refusal);
        return {
            text: message && message.content ? String(message.content) : "",
            finishReason: finishReason,
            error: "",
            keyIndex: keyIndex
        };
    }
    return { text: "", finishReason: "", error: lastError || "Không có " + LLM_NAME + " API key khả dụng", keyIndex: -1 };
}

function llmApiError(response) {
    var message = "";
    try {
        var data = JSON.parse(response.text());
        if (data && data.error && data.error.message) message = String(data.error.message);
    } catch (e) {}
    return LLM_NAME + " HTTP " + response.status + (message ? ": " + message : "");
}
