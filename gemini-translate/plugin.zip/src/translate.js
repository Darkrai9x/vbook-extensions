load('baidu.js');
load('prompts.js');

var GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
var TRANSLATION_MEMORY_TABLE = "translation_memory";
var MAX_MEMORY_ROWS = 2000;
var MAX_MEMORY_MATCHES = 80;
var MAX_LEARNED_ITEMS = 20;

function execute(text, from, to, source, model, style) {
    text = text || "";
    from = from || "auto";
    to = to || "";
    source = source || "";
    var requestedModel = model || "";
    model = normalizeModel(model);
    style = style || "natural";

    debugLog("request from=" + from + " to=" + to + " source=" + (source || "untagged") +
        " model=" + (requestedModel || "default") + " resolvedModel=" + model +
        " style=" + style + " textLength=" + text.length + " input=" + debugPreview(text));

    if (!text) {
        debugLog("result=empty-input");
        return Response.success("");
    }
    if (!to) {
        debugLog("result=error reason=missing-target-language");
        return Response.error("Chưa chọn ngôn ngữ đích");
    }

    if (!shouldUseGemini(source)) {
        debugLog("route=fallback source=" + source);
        return translateWithFallback(text, from, to, source);
    }

    var apiKeys = readApiKeys();
    if (apiKeys.length === 0) {
        debugLog("route=gemini result=error reason=no-api-key");
        return Response.error("Vui lòng thêm Gemini API key trong cài đặt extension");
    }
    debugLog("route=gemini model=" + model + " apiKeyCount=" + apiKeys.length);

    var temperature = readNumber("temperature", 0.2, 0, 2);
    var maxOutputTokens = Math.round(readNumber("max_output_tokens", 16384, 256, 65536));
    var customInstruction = readBookCustomInstruction();
    var endpoint = GEMINI_API_BASE + encodeURIComponent(model) + ":generateContent";
    var memoryContext = loadTranslationMemory(text, from, to, source);
    var learnMemory = memoryContext.enabled && readBoolean("auto_translation_memory", true);
    var systemInstruction = buildInstruction(
        from,
        to,
        source,
        style,
        customInstruction,
        memoryContext.prompt,
        learnMemory
    );

    var requestBody = JSON.stringify({
        systemInstruction: {
            parts: [{ text: systemInstruction }]
        },
        contents: [{
            role: "user",
            parts: [{ text: text }]
        }],
        generationConfig: {
            temperature: temperature,
            maxOutputTokens: maxOutputTokens
        }
    });

    var lastError = "";
    for (var keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        debugLog("gemini attempt=" + (keyIndex + 1) + "/" + apiKeys.length);
        var response = fetch(endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-goog-api-key": apiKeys[keyIndex]
            },
            body: requestBody,
            timeout: 120000
        });

        if (!response.ok) {
            lastError = readApiError(response);
            debugLog("gemini result=error status=" + response.status + " message=" + debugPreview(lastError));
            if (response.status === 401 || response.status === 403 || response.status === 429) continue;
            return Response.error(lastError);
        }

        var responseText = response.text();
        var data;
        try {
            data = JSON.parse(responseText);
        } catch (e2) {
            debugLog("gemini result=error reason=invalid-json response=" + debugPreview(responseText));
            return Response.error("Gemini trả về dữ liệu không hợp lệ");
        }

        var translated = extractText(data);
        if (!translated) {
            var reason = blockedReason(data);
            debugLog("gemini result=empty reason=" + (reason || "no-candidate-text"));
            return Response.error(reason ? "Gemini không thể dịch: " + reason : "Gemini không trả về bản dịch");
        }

        var cleaned = stripCodeFence(translated);
        var parsedResult = parseTranslationResult(cleaned, learnMemory);
        var finalText = parsedResult.translation;
        if (!finalText) {
            debugLog("gemini result=error reason=empty-translation-envelope");
            return Response.error("Gemini không trả về bản dịch");
        }

        if (learnMemory) persistTranslationMemory(memoryContext, text, parsedResult.memory);

        if (shouldRepairChinese(finalText, text, from, to)) {
            var repaired = repairChineseRemainder(
                endpoint,
                apiKeys[keyIndex],
                text,
                finalText,
                memoryContext.prompt,
                maxOutputTokens
            );
            if (repaired) finalText = repaired;
        }

        debugLog("gemini result=success outputLength=" + finalText.length + " output=" + debugPreview(finalText));
        return Response.success(finalText);
    }

    debugLog("gemini result=error reason=no-available-key message=" + debugPreview(lastError));
    return Response.error(lastError || "Không có Gemini API key khả dụng");
}

function shouldUseGemini(source) {
    if (source === "tableOfContent") return readBoolean("translate_table_of_content", false);
    if (source === "detail") return readBoolean("translate_detail", false);
    if (source === "discovery") return readBoolean("translate_discovery", false);
    return true;
}

function translateWithFallback(text, from, to, source) {
    if (readBoolean("use_qt_fallback", true)) {
        debugLog("fallback try=qt");
        var qtText = translateWithQt(text, from, to, source);
        if (qtText) {
            debugLog("qt result=success outputLength=" + qtText.length + " output=" + debugPreview(qtText));
            return Response.success(qtText);
        }
        debugLog("qt result=unavailable");
    } else {
        debugLog("fallback skip=qt reason=config-disabled");
    }

    debugLog("fallback try=baidu");
    var baiduResult = baiduTranslateText(text, from, to);
    if (baiduResult.text) {
        debugLog("baidu result=success outputLength=" + baiduResult.text.length + " output=" + debugPreview(baiduResult.text));
        return Response.success(baiduResult.text);
    }
    debugLog("baidu result=error message=" + debugPreview(baiduResult.error));
    return Response.error(baiduResult.error || "Không thể dịch bằng Baidu");
}

function translateWithQt(text, from, to, source) {
    if (to !== "vi") {
        debugLog("qt skip reason=target-not-vi target=" + to);
        return "";
    }
    if (!isChineseSource(text, from)) {
        debugLog("qt skip reason=source-not-chinese from=" + from);
        return "";
    }

    try {
        var result = Qt.translate(text, to, {
            source: source,
            chapter_name: source === "tableOfContent",
            first_line_chapter_name: source === "tableOfContent",
            first_capitalize: true
        });
        var translated = result && result.translateText ? String(result.translateText).trim() : "";
        return translated && translated !== String(text).trim() ? translated : "";
    } catch (e) {
        debugLog("qt result=exception message=" + debugPreview(String(e)));
        return "";
    }
}

function loadTranslationMemory(text, from, to, source) {
    var context = {
        enabled: false,
        bookId: "",
        prompt: "",
        existing: {},
        included: {},
        lines: []
    };

    if (!readBoolean("use_translation_memory", true)) {
        debugLog("memory disabled reason=config-disabled");
        return context;
    }

    if (source !== "chapterContent" || to !== "vi" || !isChineseSource(text, from)) return context;

    var info;
    try {
        info = localBook.getInfo();
    } catch (e) {
        debugLog("memory disabled reason=local-book-unavailable message=" + debugPreview(String(e)));
        return context;
    }

    if (!info || !info.id) {
        debugLog("memory disabled reason=no-book-context");
        return context;
    }

    context.enabled = true;
    context.bookId = String(info.id);

    try {
        var totalRows = localDatabase.count(context.bookId, TRANSLATION_MEMORY_TABLE);
        var rows;
        if (totalRows > MAX_MEMORY_ROWS) {
            var half = Math.floor(MAX_MEMORY_ROWS / 2);
            rows = localDatabase.list(context.bookId, TRANSLATION_MEMORY_TABLE, 0, half);
            var recentRows = localDatabase.list(
                context.bookId,
                TRANSLATION_MEMORY_TABLE,
                Math.max(0, totalRows - half),
                half
            );
            for (var recentIndex = 0; recentRows && recentIndex < recentRows.length; recentIndex++) {
                rows.push(recentRows[recentIndex]);
            }
        } else {
            rows = localDatabase.list(context.bookId, TRANSLATION_MEMORY_TABLE, 0, MAX_MEMORY_ROWS);
        }

        for (var i = 0; rows && i < rows.length; i++) {
            var rowKey = String(rows[i].key || "").trim();
            if (!rowKey) continue;
            context.existing[rowKey] = true;
            addStoredMemoryLine(context, rowKey, String(rows[i].value || ""), text);
        }

        if (totalRows > MAX_MEMORY_ROWS) {
            debugLog("memory rows sampled oldest+newest loaded=" + MAX_MEMORY_ROWS + " total=" + String(totalRows));
        }
    } catch (databaseError) {
        debugLog("memory database read failed=" + debugPreview(String(databaseError)));
    }

    try {
        addBookDictionary(context, text, localBook.getNames(), "name");
        addBookDictionary(context, text, localBook.getQtNames(), "name");
        addBookDictionary(context, text, localBook.getQtVietPhrases(), "term");
    } catch (dictionaryError) {
        debugLog("memory dictionary read failed=" + debugPreview(String(dictionaryError)));
    }

    if (context.lines.length > 0) {
        context.prompt = "Use this book-specific translation memory exactly. Never rename or reinterpret these entries:\n" +
            context.lines.join("\n");
    }

    debugLog("memory bookId=" + context.bookId + " matched=" + String(context.lines.length));
    return context;
}

function addStoredMemoryLine(context, source, rawValue, text) {
    var target = rawValue;
    var kind = "term";
    var note = "";
    var aliases = [];
    var details = [];

    try {
        var data = JSON.parse(rawValue);
        if (data && data.target) target = String(data.target);
        if (data && data.kind) kind = String(data.kind);
        if (data && data.note) note = String(data.note);
        if (data && Array.isArray(data.aliases)) aliases = data.aliases;
        if (data && data.gender && data.gender !== "unknown") details.push("giới tính: " + oneLine(data.gender));
        if (data && data.role) details.push("vai trò: " + oneLine(data.role));
        if (data && Array.isArray(data.relationships)) {
            for (var relationshipIndex = 0; relationshipIndex < data.relationships.length; relationshipIndex++) {
                var relationship = data.relationships[relationshipIndex];
                if (!relationship || !relationship.with || !relationship.type) continue;
                var relationshipText = oneLine(relationship.with) + ": " + oneLine(relationship.type);
                if (relationship.addressTo) relationshipText += ", gọi họ: " + oneLine(relationship.addressTo);
                if (relationship.addressFrom) relationshipText += ", họ gọi lại: " + oneLine(relationship.addressFrom);
                details.push("quan hệ " + relationshipText);
            }
        }
        if (data && data.autoNote) details.push(oneLine(data.autoNote));
    } catch (e) {}

    var matched = text.indexOf(source) >= 0;
    var validAliases = [];
    for (var aliasIndex = 0; aliasIndex < aliases.length; aliasIndex++) {
        var alias = oneLine(aliases[aliasIndex]);
        if (!alias || alias === source) continue;
        validAliases.push(alias);
        if (text.indexOf(alias) >= 0) matched = true;
    }
    if (!matched) return;

    if (note) details.unshift(note);
    var displaySource = source;
    if (validAliases.length > 0) displaySource += " (còn gọi: " + validAliases.join(", ") + ")";
    addMemoryLine(context, displaySource, target, kind, details.join("; "));
}

function addBookDictionary(context, text, dictionary, kind) {
    if (!dictionary) return;
    for (var source in dictionary) {
        if (!dictionary.hasOwnProperty(source)) continue;
        source = String(source || "").trim();
        if (!source || text.indexOf(source) < 0) continue;
        addMemoryLine(context, source, String(dictionary[source] || ""), kind, "");
        if (context.lines.length >= MAX_MEMORY_MATCHES) return;
    }
}

function addMemoryLine(context, source, target, kind, note) {
    if (!source || !target || context.included[source]) return;
    if (context.lines.length >= MAX_MEMORY_MATCHES) return;

    context.included[source] = true;
    var line = "- " + oneLine(source) + " => " + oneLine(target) + " [" + oneLine(kind || "term") + "]";
    if (note) line += " — " + oneLine(note);
    context.lines.push(line);
}

function parseTranslationResult(value, expectsMemory) {
    if (!expectsMemory) return { translation: value, memory: [] };

    try {
        var data = JSON.parse(value);
        if (data && data.translation) {
            return {
                translation: String(data.translation),
                memory: Array.isArray(data.memory) ? data.memory : []
            };
        }
    } catch (e) {
        debugLog("memory envelope invalid-json message=" + debugPreview(String(e)));
    }

    var match = value.match(/"translation"\s*:\s*"((?:\\.|[^"\\])*)"/);
    if (match) {
        try {
            return { translation: JSON.parse('"' + match[1] + '"'), memory: [] };
        } catch (e2) {}
    }

    return { translation: value, memory: [] };
}

function persistTranslationMemory(context, input, items) {
    if (!context.bookId || !Array.isArray(items) || items.length === 0) return;

    var records = [];
    for (var i = 0; i < items.length && records.length < MAX_LEARNED_ITEMS; i++) {
        var item = items[i];
        if (!item) continue;

        var source = String(item.source || "").trim();
        var target = String(item.target || "").trim();
        if (!source || !target || context.existing[source]) continue;
        if (source.length > 80 || target.length > 160) continue;
        if (!containsChinese(source) || input.indexOf(source) < 0) continue;

        var kind = normalizeMemoryKind(item.kind);
        var note = oneLine(String(item.note || ""));
        if (note.length > 300) note = note.substring(0, 300);

        records.push({
            key: source,
            value: JSON.stringify({ target: target, kind: kind, note: note })
        });
        context.existing[source] = true;
    }

    if (records.length === 0) return;

    try {
        var written = localDatabase.upsertAll(context.bookId, TRANSLATION_MEMORY_TABLE, records);
        debugLog("memory learned requested=" + String(records.length) + " written=" + String(written));
    } catch (e) {
        debugLog("memory write failed=" + debugPreview(String(e)));
    }
}

function normalizeMemoryKind(value) {
    var kind = String(value || "term").toLowerCase();
    if (kind === "character" || kind === "place" || kind === "organization" || kind === "term") {
        return kind;
    }
    return "term";
}

function shouldRepairChinese(translated, original, from, to) {
    if (!readBoolean("retry_untranslated_chinese", true)) return false;
    if (to !== "vi" || !isChineseSource(original, from)) return false;
    var count = countChinese(translated);
    if (count === 0) return false;
    debugLog("repair chinese remaining=" + String(count));
    return true;
}

function repairChineseRemainder(endpoint, apiKey, original, draft, memoryPrompt, maxOutputTokens) {
    var instruction = "You are revising a Chinese-to-Vietnamese literary translation. " +
        "Translate every remaining Chinese Han character in the draft into Vietnamese, including names, places, titles, idioms, and short fragments. " +
        "Keep the already-correct Vietnamese, paragraph breaks, HTML/Markdown, URLs, numbers, and placeholders unchanged. " +
        "Return only the complete corrected Vietnamese translation.";
    if (memoryPrompt) instruction += "\n\n" + memoryPrompt;

    var body = JSON.stringify({
        systemInstruction: { parts: [{ text: instruction }] },
        contents: [{
            role: "user",
            parts: [{ text: "SOURCE:\n" + original + "\n\nDRAFT:\n" + draft }]
        }],
        generationConfig: {
            temperature: 0,
            maxOutputTokens: maxOutputTokens
        }
    });

    try {
        var response = fetch(endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-goog-api-key": apiKey
            },
            body: body,
            timeout: 120000
        });
        if (!response.ok) {
            debugLog("repair failed status=" + String(response.status));
            return "";
        }

        var data = response.json();
        var repaired = stripCodeFence(extractText(data));
        if (!repaired) return "";

        var before = countChinese(draft);
        var after = countChinese(repaired);
        debugLog("repair result before=" + String(before) + " after=" + String(after));
        return after < before ? repaired : "";
    } catch (e) {
        debugLog("repair exception=" + debugPreview(String(e)));
        return "";
    }
}

function containsChinese(value) {
    return /[\u3400-\u9fff\uf900-\ufaff]/.test(String(value || ""));
}

function countChinese(value) {
    var matches = String(value || "").match(/[\u3400-\u9fff\uf900-\ufaff]/g);
    return matches ? matches.length : 0;
}

function oneLine(value) {
    return String(value || "").replace(/[\r\n\t]+/g, " ").trim();
}

function debugLog(message) {
    console.log("[Gemini Translate] " + String(message));
}

function debugPreview(value) {
    var text = String(value || "").replace(/[\r\n]+/g, " ");
    return text.length > 160 ? text.substring(0, 160) + "..." : text;
}

function isChineseSource(text, from) {
    var language = String(from || "auto").toLowerCase();
    if (language === "zh" || language.indexOf("zh-") === 0) return true;
    if (language !== "auto") return false;
    return /[\u3400-\u9fff\uf900-\ufaff]/.test(text);
}

function readConfig(key, fallback) {
    var value = localConfig.getItem(key);
    return value === null || value === undefined || value === "" ? fallback : String(value);
}

function readBookCustomInstruction() {
    try {
        var info = localBook.getInfo();
        if (info && info.id) {
            var key = translationBookPromptConfigKey(String(info.id));
            return readConfig(key, "").trim();
        }
    } catch (e) {
        debugLog("book prompt read failed=" + debugPreview(String(e)));
    }
    return "";
}

function readBoolean(key, fallback) {
    return readConfig(key, fallback ? "true" : "false") === "true";
}

function readApiKeys() {
    var raw = readConfig("api_key", "").trim();
    if (!raw) return [];

    var values;
    try {
        values = JSON.parse(raw);
    } catch (e) {
        values = raw.split("\n");
    }
    if (!Array.isArray(values)) values = [String(values)];

    var keys = [];
    for (var i = 0; i < values.length; i++) {
        var key = String(values[i] || "").trim();
        if (key && keys.indexOf(key) === -1) keys.push(key);
    }
    return keys;
}

function readApiError(response) {
    var errorText = response.text();
    var errorData;
    try {
        errorData = JSON.parse(errorText);
    } catch (e) {
        errorData = null;
    }
    var message = errorData && errorData.error && errorData.error.message ? String(errorData.error.message) : "";
    return "Gemini HTTP " + response.status + (message ? ": " + message : "");
}

function readNumber(key, fallback, min, max) {
    var value = parseFloat(readConfig(key, String(fallback)));
    if (isNaN(value)) value = fallback;
    if (value < min) value = min;
    if (value > max) value = max;
    return value;
}

function normalizeModel(model) {
    var selected = String(model || "").trim();
    var models = {
        "gemini-3.5-flash-lite": true,
        "gemini-3.8-flash": true,
        "gemini-3.7-flash": true,
        "gemini-3.6-flash": true,
        "gemini-3.5-flash": true,
        "gemini-3.1-flash-lite": true,
        "gemini-3.1-pro-preview": true
    };
    return models[selected] ? selected : "gemini-3.5-flash-lite";
}

function buildInstruction(from, to, source, style, customInstruction, memoryPrompt, learnMemory) {
    var sourceLanguage = from === "auto" ? "the automatically detected source language" : from;
    var instruction = "You are a professional literary translator. Translate the user text from " +
        sourceLanguage + " to " + to + ". Preserve meaning, tone, paragraph breaks, " +
        "line breaks, HTML/Markdown structure, URLs, numbers, and placeholders such as <N1> exactly.";

    var stylePrompt = loadTranslationStylePrompt(style);
    if (stylePrompt) instruction += "\n\nSTORY TRANSLATION STYLE:\n" + stylePrompt;

    if (source === "chapterContent") {
        instruction += " Produce fluent prose suitable for a book chapter.";
    } else if (source === "tableOfContent") {
        instruction += " Keep chapter numbering and make each title concise.";
    } else if (source === "detail") {
        instruction += " Preserve metadata labels and any HTML structure.";
    } else if (source === "discovery") {
        instruction += " Keep titles, tags, and short descriptions concise.";
    }

    if (customInstruction) instruction += " Additional instruction: " + customInstruction;

    if (memoryPrompt) instruction += "\n\n" + memoryPrompt;

    if (learnMemory) {
        instruction += "\n\nReturn only one valid JSON object, without Markdown fences, using this exact shape: " +
            '{"translation":"complete translated text","memory":[' +
            '{"source":"exact source substring","target":"canonical Vietnamese form",' +
            '"kind":"character|place|organization|term","note":"short gender, relationship, identity, or usage note"}' +
            "]}. The translation field must contain the complete translation. " +
            "Memory may contain at most 20 high-confidence proper names, places, organizations, cultivation terms, titles, or relationships that should stay consistent in later chapters. " +
            "Each source must be an exact Chinese substring from the user text. Do not store ordinary words, pronouns, whole sentences, uncertain guesses, or entries already supplied in translation memory.";
    } else {
        instruction += " Return only the translated text, without explanations, labels, quotation marks, or Markdown fences.";
    }
    return instruction;
}

function loadTranslationStylePrompt(style) {
    var selected = translationNormalizeStyle(style);
    try {
        var stored = localDatabase.get(TRANSLATION_PROMPT_SCOPE, TRANSLATION_PROMPT_TABLE, selected);
        if (stored !== null && stored !== undefined) {
            debugLog("prompt source=database style=" + selected + " length=" + String(stored).length);
            return String(stored).trim();
        }
    } catch (e) {
        debugLog("prompt database read failed=" + debugPreview(String(e)));
    }
    debugLog("prompt source=default style=" + selected);
    return translationDefaultPrompt(selected);
}

function extractText(data) {
    if (!data || !data.candidates || data.candidates.length === 0) return "";
    var content = data.candidates[0].content;
    if (!content || !content.parts) return "";

    var result = "";
    var fallback = "";
    for (var i = 0; i < content.parts.length; i++) {
        var part = content.parts[i];
        if (!part || !part.text) continue;
        fallback += String(part.text);
        if (!part.thought) result += String(part.text);
    }
    return result || fallback;
}

function blockedReason(data) {
    if (data && data.promptFeedback && data.promptFeedback.blockReason) {
        return String(data.promptFeedback.blockReason);
    }
    if (data && data.candidates && data.candidates.length > 0 && data.candidates[0].finishReason) {
        return String(data.candidates[0].finishReason);
    }
    return "";
}

function stripCodeFence(text) {
    var value = String(text).trim();
    var match = value.match(/^```[^\n]*\n([\s\S]*?)\n```$/);
    return match ? match[1] : value;
}
