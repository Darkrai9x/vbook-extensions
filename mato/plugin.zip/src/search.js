load('config.js');
function execute(query, page) {
    if (page && page !== "1") return Response.success([], "");

    let info = getInfo();
    if (!info) return Response.error("Không tải được thông tin truyện");

    // The site hosts only "Mato Seihei no Slave": match the query against its titles.
    let key = foldText(query || "");
    let names = [info.title].concat(info.altTitles || []);
    let matched = key === "";
    for (let i = 0; i < names.length && !matched; i++) {
        matched = foldText(names[i]).indexOf(key) !== -1;
    }

    return Response.success(matched ? [toListItem(info)] : [], "");
}

function foldText(text) {
    return String(text).toLowerCase()
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g, "a")
        .replace(/[èéẹẻẽêềếệểễ]/g, "e")
        .replace(/[ìíịỉĩ]/g, "i")
        .replace(/[òóọỏõôồốộổỗơờớợởỡ]/g, "o")
        .replace(/[ùúụủũưừứựửữ]/g, "u")
        .replace(/[ỳýỵỷỹ]/g, "y")
        .replace(/đ/g, "d")
        .replace(/\s+/g, " ")
        .trim();
}
