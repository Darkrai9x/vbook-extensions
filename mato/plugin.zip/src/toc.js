load('config.js');
function execute(url) {
    let response = fetch(apiUrl("/chapters.json"));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let data = response.json();

    // The API lists newest first; the reader expects oldest first.
    let chapters = [];
    for (let i = data.length - 1; i >= 0; i--) {
        chapters.push({
            name: data[i].title,
            url: data[i].apiUrl,
            description: String(data[i].publishedAt || "").substring(0, 10),
            lock: false,
            pay: false
        });
    }

    return Response.success(chapters);
}
