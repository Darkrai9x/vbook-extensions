let BASE_URL = "https://mato.suicaodex.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

let AUTHOR = "Takahiro, Takemura Youhei";

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function apiUrl(path) {
    return BASE_URL + "/api/v1/mato" + path;
}

function getInfo() {
    let response = fetch(apiUrl("/info.json"));
    if (!response.ok) return null;
    return response.json();
}

// MatoDex hosts a single title, so every list returns this one item.
function toListItem(info) {
    let latest = info.latestChapter ? info.latestChapter.title : "";
    return {
        name: info.title,
        link: BASE_URL + "/",
        cover: info.cover,
        description: latest,
        tag: info.status === "ongoing" ? "Đang tiến hành" : "Hoàn thành"
    };
}
