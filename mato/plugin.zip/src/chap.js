load('config.js');
function execute(url) {
    url = normalizeUrl(url);
    // Accept reader links (/read/chapter-N) as well as the API links toc.js returns.
    let read = /\/read\/([^\/?#]+)/.exec(url);
    if (read) url = apiUrl("/chapters/" + read[1] + ".json");

    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let chapter = response.json();

    let pages = chapter.pages || [];
    if (pages.length === 0) return Response.error("Chương không có ảnh");
    return Response.success(pages);
}
