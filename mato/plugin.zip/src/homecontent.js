load('config.js');
function execute(input, page) {
    if (page && page !== "1") return Response.success([], "");

    let info = getInfo();
    if (!info) return Response.error("Không tải được thông tin truyện");

    return Response.success([toListItem(info)], "");
}
