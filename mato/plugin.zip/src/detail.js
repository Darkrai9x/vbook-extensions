load('config.js');
function execute(url) {
    let info = getInfo();
    if (!info) return Response.error("Không tải được thông tin truyện");

    let ongoing = info.status === "ongoing";
    let detail = [
        "Tên khác: " + (info.altTitles || []).join(", "),
        "Số chương: " + info.chapterCount,
        "Tình trạng: " + (ongoing ? "Đang tiến hành" : "Hoàn thành")
    ];
    if (info.latestChapter) detail.push("Mới nhất: " + info.latestChapter.title);

    return Response.success({
        name: info.title,
        author: AUTHOR,
        cover: info.cover,
        description: info.description,
        detail: detail.join("<br>"),
        url: BASE_URL + "/",
        type: "comic",
        format: "comic",
        ongoing: ongoing,
        locale: "vi",
        tags: [],
        genres: [],
        suggests: [],
        reviews: [],
        comments: []
    });
}
