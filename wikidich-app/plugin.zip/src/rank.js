load("config.js");
load("crypto.js");

// Split a URL/path that may contain a querystring into { path, params }.
function splitPathParams(rawPath) {
    let qIdx = rawPath.indexOf("?");
    if (qIdx < 0) return { path: rawPath, params: {} };
    let path = rawPath.substring(0, qIdx);
    let qs = rawPath.substring(qIdx + 1);
    let params = {};
    if (qs.length > 0) {
        qs.split("&").forEach(pair => {
            if (!pair) return;
            let eq = pair.indexOf("=");
            if (eq < 0) {
                params[decodeURIComponent(pair)] = "";
            } else {
                let k = decodeURIComponent(pair.substring(0, eq));
                let v = decodeURIComponent(pair.substring(eq + 1));
                if (params[k] !== undefined) {
                    if (Array.isArray(params[k])) params[k].push(v);
                    else params[k] = [params[k], v];
                } else {
                    params[k] = v;
                }
            }
        });
    }
    return { path: path, params: params };
}

function execute(url, page) {
    if (!page) {
        page = "1";
    }

    let split = splitPathParams(url);
    let path = split.path;
    let params = split.params;
    params.page = page;
    params.count = 20;

    let response = fetchSigned(path, params);
    if (response.ok) {
        let books = [];

        let data = response.json().data
        data.books.forEach(e => {
            let tag = e.attr_gender.name;
            books.push({
                name: e.title_vi,
                link: BASE_URL + "/book/" + e.id,
                cover: e.cover,
                description: tag + ", " + e.attr_status.name,
            });
        });

        let lastPage = data.last_page;
        let currentPage = parseInt(page);
        if (currentPage < lastPage) {
            return Response.success(books, Math.trunc(parseInt(page) + 1) + "");
        } else {
            return Response.success(books, null);
        }
    }

    return null;
}
