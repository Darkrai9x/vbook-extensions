const BASE_URL = "https://api.truyenreview.com";
const API_KEY = "F06E1BF5E9BABC2F11C8C6849DEFB04E";
const API_SECRET = "9884CFCB6021B83545E30185C0A1AAA1";
const DECOY = "0A47AC78ABB84EFAC046F380890739FB";
const VERSION = "0.1.10";

function getEffectiveKey() {
    return API_SECRET.substring(0, API_SECRET.length / 2) + DECOY.substring(16);
    // = "9884CFCB6021B835" + "C046F380890739FB"
    // = "9884CFCB6021B835C046F380890739FB"
}

function serializeArray(arr) {
    let list = [];
    for (let i = 0; i < arr.length; i++) {
        let v = arr[i];
        if (typeof v === "boolean") list.push(String(v));
        else if (typeof v === "number") list.push(String(v));
        else if (typeof v === "string") list.push(v);
    }
    if (list.length > 0) list.sort();
    return list;
}

function serializeParams(params) {
    if (!params || typeof params !== "object") return "";
    let keys = Object.keys(params);
    if (keys.length === 0) return "";
    keys.sort().reverse(); // reverse alphabetical (Java TreeMap reverseOrder)
    let parts = [];
    for (let k of keys) {
        let v = params[k];
        if (v === null || v === undefined) continue;
        if (Array.isArray(v)) {
            for (let it of serializeArray(v)) parts.push(k + "=" + it);
        } else if (typeof v === "boolean" || typeof v === "number" || typeof v === "string") {
            parts.push(k + "=" + String(v));
        }
    }
    if (parts.length === 0) return "";
    return "?" + parts.join("&");
}

function buildSignMessage(path, params, timeMs) {
    let s = path;
    if (params) {
        let qs = serializeParams(params);
        let reversed = qs.split("").reverse().join("");
        s += reversed;
    }
    let mid = Math.floor(s.length / 2);
    return s.substring(0, mid) + String(timeMs) + s.substring(mid);
}

function sign(path, params, timeMs) {
    let msg = buildSignMessage(path, params, timeMs);
    let hash = CryptoJS.HmacSHA256(msg, getEffectiveKey());
    return CryptoJS.enc.Base64.stringify(hash);
}

function createHeaders(path, params) {
    let time = new Date().getTime() + "";
    let signature = sign(path, params || null, parseInt(time));
    return {
        "Api-Key": API_KEY,
        "Signature": signature,
        "Request-Time": time,
        "App-Agent": "os=android;native_version=" + VERSION + ";version=" + VERSION,
        "User-Agent": "okhttp/4.9.2"
    };
}

// Build a URL-encoded query string from a params object (for use in fetch URL).
// Sorting/order does NOT matter here — the signature is computed separately from
// the raw params object via createHeaders().
function buildQueryString(params) {
    if (!params) return "";
    let parts = [];
    for (let k of Object.keys(params)) {
        let v = params[k];
        if (v === null || v === undefined) continue;
        if (Array.isArray(v)) {
            for (let it of v) parts.push(k + "=" + encodeURIComponent(it));
        } else {
            parts.push(k + "=" + encodeURIComponent(v));
        }
    }
    return parts.length === 0 ? "" : "?" + parts.join("&");
}

// Convenience: do a signed GET. `path` MUST be the bare path without querystring.
function fetchSigned(path, params) {
    let url = BASE_URL + path + buildQueryString(params);
    return fetch(url, { headers: createHeaders(path, params || null) });
}
