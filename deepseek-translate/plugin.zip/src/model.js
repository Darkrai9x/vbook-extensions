function execute() {
    return Response.success([
        {
            id: "deepseek-flash",
            name: "DeepSeek Flash",
            description: "Mặc định; DeepSeek V4.1 Flash không suy nghĩ, nhanh và rẻ cho khối lượng dịch lớn",
            isNetworkRequired: true
        },
        {
            id: "deepseek-flash-thinking",
            name: "DeepSeek Flash (Thinking)",
            description: "Flash có suy nghĩ trước khi dịch; kỹ hơn nhưng chậm hơn",
            isNetworkRequired: true
        },
        {
            id: "deepseek-v4-pro",
            name: "DeepSeek V4 Pro",
            description: "Chất lượng cao hơn Flash, không suy nghĩ",
            isNetworkRequired: true
        },
        {
            id: "deepseek-v4-pro-thinking",
            name: "DeepSeek V4 Pro (Thinking)",
            description: "Chất lượng cao nhất; suy nghĩ trước khi dịch, chậm và đắt nhất",
            isNetworkRequired: true
        }
    ]);
}
