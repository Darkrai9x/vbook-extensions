function execute() {
    return Response.success([
        {
            title: "Mới cập nhật",
            script: "news.js",
            input: "https://gacsach.club"
        }
    ])
}

