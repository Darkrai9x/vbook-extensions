let BASE_URL = "https://www.right.com.cn/forum";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/$/, "");
    }
} catch (error) {
}

// Discuz serves a different (mobile) template to a phone's user agent: always ask as a desktop browser
const DESKTOP_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";
function get(url) {
    return fetch(url, { headers: { "User-Agent": DESKTOP_UA } });
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?right\.com\.cn\/forum/i, BASE_URL);
}

// Discuz links are relative to /forum/: "thread-1-1-1.html", "forum.php?mod=..."
function absUrl(href) {
    if (!href) return "";
    if (href.indexOf("http") === 0) return normalizeUrl(href);
    return BASE_URL + "/" + href.replace(/^\//, "");
}

function escapeHtml(text) {
    return String(text || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function topicId(url) {
    let m = String(url).match(/thread-(\d+)-/) || String(url).match(/tid=(\d+)/);
    return m ? m[1] : "";
}

// Thread rows of a board page ("forum-N-1.html")
function parseThreads(doc, page) {
    let items = doc.select("tbody[id^=normalthread_], tbody[id^=stickthread_]").map(function (el) {
        let a = el.select("a.xst").first();
        if (!a) return null;
        let cells = el.select("td.by");
        let board = "", author = "", started = "", last = null;
        cells.forEach(function (td, index) {
            let cite = td.select("cite a").first();
            if (td.select("cite a").size() === 0 || !cite) {
                board = td.text().trim();
                return;
            }
            let when = td.select("em").text().trim();
            if (!author) {
                author = cite.text().trim();
                started = when;
            } else {
                last = { user: cite.text().trim(), time: when };
            }
        });
        let num = el.select("td.num").first();
        return {
            name: escapeHtml(a.text().trim()),
            link: BASE_URL + "/thread-" + topicId(a.attr("href")) + "-1-1.html",
            author: author,
            time: started,
            replies: num && num.select("a").first() ? num.select("a").first().text() : "",
            views: num && num.select("em").first() ? num.select("em").first().text() : "",
            board: board,
            last_post: last,
            pinned: el.attr("id").indexOf("stickthread_") === 0
        };
    }).filter(function (x) { return x; });
    return Response.success(items, "");
}
