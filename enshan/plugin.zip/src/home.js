load('config.js');
// robots.txt only allows the forum index, the first page of a board and the thread pages:
// no guide pages (latest, hot) and no board paging.
function execute() {
    return Response.success([
        { title: "版块", input: "", script: "explore.js", type: "explore" }
    ]);
}
