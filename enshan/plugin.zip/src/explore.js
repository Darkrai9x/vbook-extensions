load('config.js');
// The forum index: a block of boards per category.
function execute() {
    let response = get(BASE_URL + "/forum.php");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let sections = [];
    response.html().select("div.bm.bmw").forEach(function (block) {
        let title = block.select(".bm_h h2 a").first();
        let boards = block.select("td.fl_g dl").map(function (dl) {
            let a = dl.select("dt a").first();
            if (!a) return null;
            let m = a.attr("href").match(/forum-(\d+)-/) || a.attr("href").match(/fid=(\d+)/);
            if (!m) return null;
            let stats = dl.select("dd em");
            return {
                name: a.text().trim(),
                link: absUrl(a.attr("href")),
                threads: stats.size() > 0 ? stats.get(0).text().replace(/^[^:：]*[:：]\s*/, "") : "",
                posts: stats.size() > 1 ? stats.get(1).text().replace(/^[^:：]*[:：]\s*/, "") : "",
                action: { type: "list", name: a.text().trim(), script: "list.js", input: "fid:" + m[1] }
            };
        }).filter(function (x) { return x; });
        if (boards.length === 0) return;
        sections.push({ id: "cat_" + sections.length, title: title ? title.text().trim() : "", type: "board_list", items: boards });
    });
    if (sections.length === 0) return Response.error("Không tải được danh sách版块");
    return Response.success(sections);
}
