load('config.js');
// The first page of a board (`input` = "fid:<id>"). The site's robots.txt disallows the other
// pages of a board, so there is no next page.
function execute(input, page) {
    if (page) return Response.success([], "");
    let response = get(BASE_URL + "/forum-" + input.substring(4) + "-1.html");
    if (!response.ok) return Response.error("HTTP " + response.status);
    return parseThreads(response.html(), "1");
}
