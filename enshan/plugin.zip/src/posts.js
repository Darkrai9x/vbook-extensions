load('config.js');
// One page of a thread: `page` is the page number, "" on the first call.
function execute(url, page) {
    let tid = topicId(url);
    if (!tid) return Response.error("Link chủ đề không hợp lệ");
    page = page || "1";
    let response = get(BASE_URL + "/thread-" + tid + "-" + page + "-1.html");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    doc.select("script, noscript, .pstatus, .attach_nopermission, .rate, .po").remove();
    // lazy images keep a loading gif in src and the real one in `file`
    doc.select("img[file]").forEach(function (img) { img.attr("src", img.attr("file")); });

    let posts = doc.select("#postlist > div[id^=post_]").map(function (el) {
        let body = el.select("td.t_f").first();
        let name = el.select(".authi a.xw1").first();
        let avatar = el.select("img.user_avatar").first();
        let no = el.select(".plc .pi strong a em").first();
        let floorText = no ? no.text().trim() : "";
        let floor = /^\d+$/.test(floorText) ? "#" + floorText : (floorText ? floorText : "");
        let when = el.select("em[id^=authorposton]").text().replace(/^发表于\s*/, "").trim();
        let credit = el.select(".i dl dd a").first();
        return {
            id: el.attr("id").replace("post_", ""),
            floor: floor,
            url: BASE_URL + "/thread-" + tid + "-" + page + "-1.html#" + el.attr("id"),
            is_op: floorText === "1",
            time: when,
            user: {
                name: name ? name.text().trim() : "",
                avatar: avatar ? avatar.attr("src") : "",
                link: name ? absUrl(name.attr("href")) : "",
                reputation: credit ? credit.text().trim() : ""
            },
            content: body ? fixHtml(body.html()) : "",
            content_format: "html"
        };
    });

    let total = 1;
    let label = doc.select(".pg label span").first();
    let m = label ? (label.attr("title") || "").match(/(\d+)/) : null;
    if (m) total = parseInt(m[1]);
    doc.select(".pg a, .pg strong").forEach(function (a) { total = Math.max(total, parseInt(a.text()) || 1); });
    let current = parseInt(page);
    return Response.success({ posts: posts, page: current, total_pages: Math.max(total, current) },
        current < total ? String(current + 1) : "");
}

function fixHtml(html) {
    return html
        .replace(/<div class="locked">[\s\S]*?<\/div>/g, "<p><i>[Nội dung ẩn: cần đăng nhập và trả lời]</i></p>")
        .replace(/(src|href)="(?!https?:|\/\/|data:|#|javascript)([^"]*)"/g, '$1="' + BASE_URL + '/$2"')
        .replace(/(?:<br\s*\/?>\s*){3,}/g, "<br><br>")
        .replace(/(?:\s*<br\s*\/?>)+\s*$/, "");
}
