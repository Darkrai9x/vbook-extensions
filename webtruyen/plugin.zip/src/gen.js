load('config.js');

// `page` is the absolute next-page URL taken from the site's pagination.
function execute(url, page) {
    var target = page && page.indexOf("http") === 0 ? page : url;
    if (target.charAt(target.length - 1) !== "/") target += "/";
    var response = fetch(target);
    if (!response.ok) return Response.error("HTTP " + response.status);
    var doc = response.html();

    var data = [];
    doc.select(".list-truyen .row[itemtype]").forEach(function (e) {
        var link = e.select("h3.truyen-title a").first();
        if (!link) return;
        data.push({
            name: link.text(),
            link: link.attr("href"),
            cover: e.select(".lazyimg").attr("data-image"),
            description: e.select(".author").text(),
            host: BASE_URL
        });
    });

    var next = doc.select(".pagination li.active + li a").attr("href");
    return Response.success(data, next || "");
}
