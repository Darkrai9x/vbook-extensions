load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    var doc = response.html();

    var content = doc.select("#chapter-c").first();
    if (!content) return Response.error("Không tìm thấy nội dung chương");
    content.select("script,a,iframe,noscript,.ads-responsive").remove();
    return Response.success(content.html(), doc.select(".chapter-title").text());
}
