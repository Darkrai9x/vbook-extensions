load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.charAt(url.length - 1) !== "/") url += "/";
    var response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    var doc = response.html();

    var genres = [];
    doc.select(".info a[itemprop=genre]").forEach(function (e) {
        genres.push({ title: e.text(), input: e.attr("href"), script: "gen.js" });
    });

    var info = doc.select(".info").first();
    var infoHtml = info ? info.html() : "";
    return Response.success({
        name: doc.select("h1.title").text(),
        cover: doc.select(".book img").attr("src"),
        author: doc.select(".info a[itemprop=author]").text(),
        description: doc.select(".desc-text").html(),
        detail: infoHtml,
        ongoing: infoHtml.indexOf("Full") < 0,
        genres: genres,
        host: BASE_URL
    });
}
