load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.charAt(url.length - 1) !== "/") url += "/";
    var response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    var doc = response.html();

    var data = [];
    doc.select(".list-chapter li a").forEach(function (e) {
        data.push({ name: e.text(), url: e.attr("href"), host: BASE_URL });
    });
    return Response.success(data);
}
