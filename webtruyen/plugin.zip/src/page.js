load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL).replace(/\/+$/, "");
    var response = fetch(url + "/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    var doc = response.html();

    var lastPage = 1;
    doc.select(".pagination a[href*=/trang-]").forEach(function (e) {
        var match = e.attr("href").match(/\/trang-(\d+)\//);
        if (match && parseInt(match[1], 10) > lastPage) lastPage = parseInt(match[1], 10);
    });

    var pages = [];
    for (var i = 1; i <= lastPage; i++) pages.push(url + "/trang-" + i + "/");
    return Response.success(pages);
}
