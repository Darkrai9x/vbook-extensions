load('config.js');

function execute(key, page) {
    var url;
    if (page && page.indexOf("http") === 0) {
        url = page;
    } else {
        url = BASE_URL + "/tim-kiem/?tukhoa=" + key;
        if (page) url = url + "&paged=" + page;
    }

    var r = fetch(url);
    if (!r.ok) return Response.error("HTTP " + r.status);
    var doc = r.html();

    var next = doc.select("ul.pagination li.active + li a").attr("href");

    var items = doc.select("a[itemprop=url][title]");
    var data = [];
    for (var i = 0; i < items.size(); i++) {
        var e = items.get(i);
        data.push({
            name: e.attr("title"),
            link: e.attr("href"),
            host: BASE_URL
        });
    }

    return Response.success(data, next ? next : "");
}
