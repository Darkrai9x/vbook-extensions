function execute() {
    return Response.success([
        {title: "Top Ngày", input: "https://truyenqqvip.com/top-ngay.html", script: "gen.js"},
        {title: "Top Tuần", input: "https://truyenqqvip.com/top-tuan.html", script: "gen.js"},
        {title: "Top Tháng", input: "https://truyenqqvip.com/top-thang.html", script: "gen.js"},
        {title: "Yêu Thích", input: "https://truyenqqvip.com/truyen-yeu-thich.html", script: "gen.js"},
        {title: "Mới Cập Nhật", input: "https://truyenqqvip.com/truyen-moi-cap-nhat.html", script: "gen.js"},
        {title: "Truyện Mới", input: "https://truyenqqvip.com/truyen-tranh-moi.html", script: "gen.js"},
        {title: "Truyện Full", input: "https://truyenqqvip.com/truyen-hoan-thanh.html", script: "gen.js"}
    ]);
}
