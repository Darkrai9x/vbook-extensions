load('config.js');
// One tab per slot set in the settings, in slot order, without repeats.
function execute() {
    let catalog = tabCatalog(loadBoards() || []);
    let tabs = [];
    let used = {};
    for (let i = 1; i <= TAB_SLOTS; i++) {
        let label = slotValue(i);
        catalog.forEach(function (c) {
            if (c.label === label && !used[label]) {
                used[label] = true;
                tabs.push(c.tab);
            }
        });
    }
    // every slot off (or a board that vanished): never leave the home empty
    return Response.success(tabs.length > 0 ? tabs : [FIXED_TABS[0]]);
}
