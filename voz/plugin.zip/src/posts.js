load('config.js');
// One page of a thread's posts. `page` is the page number, "" on the first call.
function execute(url, page) {
    url = normalizeUrl(url).replace(/\/(page-\d+)?\/?$/, "");
    page = page || "1";
    let pageUrl = page === "1" ? url + "/" : url + "/page-" + page;
    let response = fetch(pageUrl);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    // Lazy images keep a data: placeholder in src and the real url in data-src; the DOM
    // setter doesn't stick, so rewrite the serialized html (regex is unavoidable here).
    doc.select("article.message--post noscript, article.message--post script").remove();
    // quotes already hold the full text; the "click to expand" link is only for the web page
    doc.select("article.message--post .bbCodeBlock-expandLink").remove();
    // embedded post cards: keep the title, preview and footer line; the avatar, forum label,
    // time and reactions only turn into stray boxes and loose words in the reader
    doc.select("article.message--post .embed .contentRow-figure, article.message--post .embed .label, " +
        "article.message--post .embed .contentRow-minor, article.message--post .embed .embed-footer-opposite").remove();

    let posts = doc.select("article.message--post").map(function (el) {
        let name = el.select(".message-name .username").first();
        let body = el.select(".message-body .bbWrapper").first();
        let floor = el.select(".message-attribution-opposite li a").last();
        let user = {
            name: name ? name.text() : "",
            avatar: el.select(".message-avatar img").first() ? el.select(".message-avatar img").first().attr("src") : "",
            link: name ? absUrl(name.attr("href")) : "",
            title: el.select(".message-userTitle").text()
        };
        return {
            id: el.select(".u-anchorTarget").first() ? el.select(".u-anchorTarget").first().attr("id").replace("post-", "") : "",
            floor: floor ? floor.text().trim() : "",
            url: absUrl(el.select(".message-attribution-main a").first() ? el.select(".message-attribution-main a").first().attr("href") : ""),
            is_op: !!floor && floor.text().trim() === "#1",
            time: timeOf(el.select(".message-attribution-main").first() || el),
            user: user,
            reactions: reactionsOf(el),
            content: body ? fixHtml(body.html()) : "",
            content_format: "html"
        };
    });

    let totalPages = 1;
    doc.select(".pageNav-main .pageNav-page a").forEach(function (a) {
        totalPages = Math.max(totalPages, parseInt(a.text()) || 1);
    });
    let current = parseInt(page);
    return Response.success({ posts: posts, page: current, total_pages: Math.max(totalPages, current) },
        current < totalPages ? String(current + 1) : "");
}

function fixHtml(html) {
    html = html
        // smilies are text-sized: without the flag a smilie alone on its line becomes a full-width image
        .replace(/<img([^>]*class="smilie"[^>]*)>/g, '<img data-inline="true"$1>')
        // the reader drops iframes: a youtube embed becomes a plain link so the video isn't lost
        .replace(/<iframe[^>]*src="(?:https?:)?\/\/(?:www\.)?youtube(?:-nocookie)?\.com\/embed\/([\w-]+)[^"]*"[^>]*>\s*<\/iframe>/g,
            '<p><a href="https://www.youtube.com/watch?v=$1">https://www.youtube.com/watch?v=$1</a></p>')
        // quote header "X đã nói:" → bold line (no blue link), and no stray <br> closing the quote body
        .replace(/<div class="bbCodeBlock-title">\s*(?:<a [^>]*>)?\s*([^<]*?)\s*(?:<\/a>)?\s*<\/div>/g, '<p><b>$1</b></p>')
        .replace(/(?:<br\s*\/?>\s*)+(<\/div>\s*<\/div>\s*<\/blockquote>)/g, '$1')
        .replace(/src="data:[^"]*"([^>]*?)data-src="([^"]*)"/g, 'src="$2"$1')
        .replace(/(src|href)="\/(?!\/)/g, '$1="' + BASE_URL + '/');
    html = html
        // the reader gives every blank line a paragraph gap on top of the line itself, so runs of
        // <br> read much looser than on the web: keep one blank line at most, none around an image
        .replace(/(?:<br\s*\/?>\s*){3,}/g, "<br><br>")
        .replace(/(?:<br\s*\/?>\s*)+(<div class="bbImageWrapper|<ul|<ol)/g, "$1")
        .replace(/(<div class="bbImageWrapper[^>]*>[\s\S]*?<\/div>)(?:\s*<br\s*\/?>)+/g, "$1")
        .replace(/(?:\s*<br\s*\/?>)+\s*$/, "");
    return foldQuotes(html);
}

const QUOTE_FOLD_CHARS = 300;

// Long quotes get `data-fold`: the reader clamps them to a few lines with a "tap to expand" fade,
// like the web. Innermost quote first, so a nested quote is judged on its own.
function foldQuotes(html) {
    let quote = /<blockquote[^>]*bbCodeBlock--quote[^>]*>((?:(?!<blockquote[^>]*bbCodeBlock--quote)[\s\S])*?)<\/blockquote>/;
    for (let i = 0; i < 200 && quote.test(html); i++) {
        html = html.replace(quote, function (all, inner) {
            let text = inner.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
            return (text.length > QUOTE_FOLD_CHARS ? "<blockquote data-fold=\"1\">" : "<blockquote>") + inner + "</blockquote>";
        });
    }
    return html;
}

// Reactions of one post: [{ type, icon, count, users }], one per kind. The post only shows the kinds and
// the first names, so the counts and the full list of who reacted come from the post's reactions page.
function reactionsOf(el) {
    let bar = el.select(".reactionsBar").first();
    if (!bar) return [];
    let kinds = bar.select("img.reaction-image").map(function (img) {
        return { type: img.attr("alt"), icon: absUrl(img.attr("src")), count: 0, users: [] };
    });
    if (kinds.length === 0) return [];
    let link = bar.select("a.reactionsBar-link").first();
    let href = link ? link.attr("href") : "";
    if (!href) return kinds;
    try {
        let page = fetch(absUrl(href));
        if (!page.ok) return kinds;
        let doc = page.html();
        // tab 0 is "All" and lists everyone with their reaction (the other panes load on demand)
        let tabs = doc.select(".tabs-tab");
        let who = {};
        doc.select(".js-reactionTabPanes > li").first().select(".contentRow").forEach(function (row) {
            let img = row.select("img.reaction-image").first();
            let name = row.select(".contentRow-header .username").first();
            if (!img || !name) return;
            (who[img.attr("alt")] = who[img.attr("alt")] || []).push(name.text());
        });
        let result = [];
        for (let i = 1; i < tabs.size(); i++) {
            let tab = tabs.get(i);
            let img = tab.select("img.reaction-image").first();
            let m = tab.select(".reaction-text").text().match(/\((\d+)\)/);
            let type = img ? img.attr("alt") : "";
            result.push({ type: type, icon: img ? absUrl(img.attr("src")) : "", count: m ? parseInt(m[1]) : 0, users: who[type] || [] });
        }
        return result.length > 0 ? result : kinds;
    } catch (e) {
        return kinds;
    }
}
