let BASE_URL = "https://voz.vn";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

// "/t/slug.123/" -> absolute url on BASE_URL
function absUrl(href) {
    if (!href) return "";
    if (href.indexOf("http") === 0) return normalizeUrl(href);
    return BASE_URL + (href.indexOf("/") === 0 ? "" : "/") + href;
}

// XenForo time element: epoch seconds, formatted by the app
function timeOf(el) {
    let t = el.select("time").first();
    if (!t) return "";
    return t.attr("data-timestamp") || t.text();
}

// Boards listed on the forum index: [{ id, name, href, threads, posts }]
function loadBoards() {
    let response = fetch(BASE_URL + "/");
    if (!response.ok) return null;
    return response.html().select(".node--forum").map(function (el) {
        let a = el.select(".node-title a").first();
        let stats = el.select(".node-statsMeta dd");
        let href = a.attr("href");
        let m = href.match(/\.(\d+)\/?$/);
        return {
            id: m ? m[1] : href,
            name: a.text(),
            href: href,
            threads: stats.size() > 0 ? stats.get(0).text() : "",
            posts: stats.size() > 1 ? stats.get(1).text() : ""
        };
    });
}

const NO_TAB = "Không";
const TAB_SLOTS = 8;
// Home tabs of voz.vn's top menu; the settings can reorder, drop, or replace them.
const FIXED_TABS = [
    { title: "Diễn đàn", input: "", script: "explore.js", type: "explore" },
    { title: "Bài viết mới", input: "/whats-new/posts/", script: "list.js" },
    { title: "Nóng", input: "/feeds/hot", script: "list.js" },
    { title: "Thịnh hành", input: "/feeds/trending", script: "list.js" },
    { title: "Mới", input: "/feeds/new", script: "list.js" }
];

// Board names are not unique ("Thời trang & Làm đẹp" twice): add the id to repeated ones.
function boardLabel(b, boards) {
    let same = boards.filter(function (x) { return x.name === b.name; }).length;
    return same > 1 ? b.name + " (#" + b.id + ")" : b.name;
}

// Everything a tab slot can show: the fixed tabs, then every board.
function tabCatalog(boards) {
    let catalog = FIXED_TABS.map(function (t) { return { label: t.title, tab: t }; });
    boards.forEach(function (b) {
        catalog.push({ label: boardLabel(b, boards), tab: { title: b.name, input: b.href, script: "list.js" } });
    });
    return catalog;
}

// Slot i shows the fixed tab of the same position until the user changes it.
function slotDefault(i) {
    return i <= FIXED_TABS.length ? FIXED_TABS[i - 1].title : NO_TAB;
}

function slotValue(i) {
    return localConfig.getItem("home_tab_" + i, slotDefault(i)) || slotDefault(i);
}
