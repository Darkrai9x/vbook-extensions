load('config.js');
// TAB_SLOTS dropdowns that decide the home tabs, in order (see home.js).
function execute() {
    let boards = loadBoards() || [];
    let values = [NO_TAB].concat(tabCatalog(boards).map(function (c) { return c.label; }));

    let config = {};
    for (let i = 1; i <= TAB_SLOTS; i++) {
        config["home_tab_" + i] = {
            title: "Tab " + i,
            subtitle: "Tab thứ " + i + " ở trang chủ",
            default: slotValue(i),
            values: values,
            mode: "select"
        };
    }
    return Response.success(config);
}
