load('config.js');
function execute() {
    let all = loadBoards();
    if (!all) return Response.error("Không tải được danh sách chuyên mục");

    let boards = all.map(function (b) {
        return {
            name: b.name,
            link: absUrl(b.href),
            threads: b.threads,
            posts: b.posts,
            action: { type: "list", name: b.name, script: "list.js", input: b.href }
        };
    });

    return Response.success([
        {
            id: "boards",
            title: "Chuyên mục",
            type: "board_list",
            items: boards
        }
    ]);
}
