load('config.js');
// Thread list of a board (or "what's new"). `page` is the next page's path, "" on the first call.
function execute(input, page) {
    let url = page && page.indexOf("/") === 0 ? BASE_URL + page : absUrl(input);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let items = doc.select(".structItem--thread").map(function (el) {
        let a = el.select(".structItem-title a[href*=/t/]").last();
        if (!a) return null;
        let meta = el.select(".structItem-cell--meta dd");
        let latest = el.select(".structItem-cell--latest .username").first();
        return {
            // html: the thread's prefix labels as <tag>, then the title
            name: tagsOf(el) + escapeHtml(a.text().trim()),
            link: absUrl(a.attr("href")),
            author: el.select(".structItem-parts .username").first() ? el.select(".structItem-parts .username").first().text() : "",
            avatar: el.select(".structItem-cell--icon img").first() ? el.select(".structItem-cell--icon img").first().attr("src") : "",
            time: timeOf(el.select(".structItem-startDate").first() || el),
            replies: meta.size() > 0 ? meta.get(0).text() : "",
            views: meta.size() > 1 ? meta.get(1).text() : "",
            board: el.select(".structItem-parts a[href*=/f/]").text(),
            last_post: latest ? { user: latest.text(), time: timeOf(el.select(".structItem-cell--latest").first()) } : null,
            pinned: !el.select(".structItem-status--sticky").isEmpty(),
            locked: !el.select(".structItem-status--locked").isEmpty()
        };
    }).filter(function (x) { return x; });

    let next = doc.select("a.pageNav-jump--next").attr("href");
    return Response.success(items, next || "");
}

// voz's own label colors: [fill, text] by the `label--<name>` class of a thread prefix
const LABEL_COLORS = {
    primary: ["#ebf1f9", "#23497b"],
    accent: ["#ffe0cc", "#ff6600"],
    orange: ["#ffcc00", "#000000"],
    red: ["#e00000", "#ffffff"],
    green: ["#008000", "#ffffff"],
    royalBlue: ["#4169e1", "#ffffff"],
    olive: ["#808000", "#ffffff"],
    gray: ["#808080", "#ffffff"]
};

// The prefixes of a thread as `<tag bg="…" color="…">text</tag> `, one per label
function tagsOf(el) {
    return el.select(".structItem-title .labelLink .label").map(function (label) {
        let m = (label.attr("class") || "").match(/label--(\w+)/);
        let c = m ? LABEL_COLORS[m[1]] : null;
        return "<tag" + (c ? ' bg="' + c[0] + '" color="' + c[1] + '"' : "") + ">" + escapeHtml(label.text().trim()) + "</tag> ";
    }).join("");
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
