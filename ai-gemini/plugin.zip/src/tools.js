// Tool cho AI: TẤT CẢ do app định nghĩa/xử lý — extension chỉ chuyển tiếp qua
// host API `ai.*` (khai trong core.js).
//  - ai.getToolList()          -> mảng function declarations (tool đang bật).
//  - ai.executeTool(name, args)-> object kết quả.
// Thêm tool mới = sửa app (AiTool.ALL + dispatch), KHÔNG đụng extension.
// Lazy: core.js (khai `ai`) được nối SAU file này nên không gọi ở top-level;
// chỉ gọi khi execute() chạy (lúc đó toàn bộ script đã eval xong).
function getToolDeclarations() {
    return ai.getToolList();
}

// Trạng thái CÓ CẤU TRÚC gửi về app: {type, ...data}. App tự dịch nhãn theo
// localization — extension KHÔNG gửi text đã dịch.
function emitStatus(type, data) {
    var payload = { type: type };
    if (data) for (var k in data) if (data.hasOwnProperty(k)) payload[k] = data[k];
    ai.emitStatus(JSON.stringify(payload));
}

// Chạy 1 tool, trả về object kết quả (gói vào functionResponse gửi lại Gemini).
function runTool(name, args) {
    return ai.executeTool(name, args || {});
}
