load("common.js");

// Hoàn thành 1 lần (blocking). Nhận messagesJson, trả toàn bộ text.
function execute(messagesJson, model) {
    var keys = geminiApiKeys();
    if (keys.length === 0) throw aiError("no_key");

    var messages = JSON.parse(messagesJson);
    var body = buildGeminiBody(messages);
    var url = GEMINI_BASE + "/" + geminiModel(model) + ":generateContent";

    var lastError = "";
    var lastMsg = "";
    for (var i = 0; i < keys.length; i++) {
        var response = fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-goog-api-key": keys[i]
            },
            body: JSON.stringify(body)
        });

        if (response.ok) {
            var data = response.json();
            if (!data.candidates || data.candidates.length === 0) {
                var reason = data.promptFeedback && data.promptFeedback.blockReason;
                throw aiError(reason ? "blocked" : "empty");
            }
            return Response.success(extractCandidateText(data.candidates[0]));
        }

        var errMsg = geminiErrorMessage(response);
        lastError = geminiErrorCode(response.status);
        lastMsg = errMsg;
        // Key hết quota / không hợp lệ -> thử key kế. Lỗi khác -> dừng luôn.
        if (!isKeyExhausted(response.status)) throw aiError(lastError, errMsg);
    }

    throw aiError(lastError || "all_keys_failed", lastMsg);
}
