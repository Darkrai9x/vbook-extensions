// Dùng chung cho chat.js + chat_stream.js: dựng URL + body Gemini từ danh sách
// message chuẩn của vBook ([{role:"system"|"user"|"assistant", content}]).

var GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

// App tự inject mỗi config key thành biến toàn cục `const <key> = "<value>"`
// (không có localConfig.getItem). Các hàm dưới đọc thẳng biến đó; cfg() bọc lại
// để an toàn khi biến chưa được inject (typeof undefined).
function cfg(value, fallback) {
    return (typeof value !== "undefined" && value !== null && value !== "") ? value : fallback;
}

// Ưu tiên model app truyền xuống (người dùng chọn trong màn chat), sau đó config.
function geminiModel(override) {
    if (override) return override;
    return cfg(typeof model !== "undefined" ? model : "", "gemini-flash-latest");
}

// api_key là list (mode "list") — app lưu dạng JSON array ["k1","k2"].
// Tolerant: nếu không phải JSON hợp lệ (giá trị cũ) thì tách theo dòng.
function geminiApiKeys() {
    var raw = cfg(typeof api_key !== "undefined" ? api_key : "", "");
    if (!raw) return [];

    var arr;
    try {
        arr = JSON.parse(raw);
    } catch (e) {
        arr = raw.split("\n");
    }
    if (!Array.isArray(arr)) arr = [String(arr)];

    var keys = [];
    for (var i = 0; i < arr.length; i++) {
        var k = String(arr[i]).trim();
        if (k) keys.push(k);
    }
    return keys;
}

// Số hợp lệ từ 1 giá trị config (string), fallback nếu rỗng/không hợp lệ.
function configNumber(value, fallback) {
    if (value === null || value === undefined || value === "") return fallback;
    var n = parseFloat(value);
    return isNaN(n) ? fallback : n;
}

// Chuyển messages vBook -> body Gemini. System gộp vào systemInstruction,
// user/assistant -> contents với role user/model.
function buildGeminiBody(messages) {
    var systemParts = [];
    var contents = [];
    for (var i = 0; i < messages.length; i++) {
        var m = messages[i];
        if (!m || !m.content) continue;
        if (m.role === "system") {
            systemParts.push(m.content);
        } else {
            contents.push({
                role: m.role === "assistant" ? "model" : "user",
                parts: [{ text: m.content }]
            });
        }
    }

    var body = {
        contents: contents,
        generationConfig: {
            temperature: configNumber(typeof temperature !== "undefined" ? temperature : null, 0.7),
            topP: configNumber(typeof top_p !== "undefined" ? top_p : null, 0.95),
            topK: configNumber(typeof top_k !== "undefined" ? top_k : null, 40),
            maxOutputTokens: configNumber(typeof max_output_tokens !== "undefined" ? max_output_tokens : null, 2048)
        }
    };

    // Mức suy nghĩ (Gemini 3): low = nhanh/rẻ, high = kỹ hơn/chậm hơn.
    var thinkingLevel = cfg(typeof thinking_level !== "undefined" ? thinking_level : "", "low");
    if (thinkingLevel === "low" || thinkingLevel === "high") {
        body.generationConfig.thinkingConfig = { thinkingLevel: thinkingLevel };
    }

    if (systemParts.length > 0) {
        body.systemInstruction = { parts: [{ text: systemParts.join("\n\n") }] };
    }

    return body;
}

// Lỗi quota/key: 429 (hết quota) hoặc 403 (key sai/không quyền) -> thử key kế.
function isKeyExhausted(status) {
    return status === 429 || status === 403;
}

// Mã lỗi CHUẨN (không phải text đã dịch) theo HTTP status. Ném dạng
// "ai_error:<code>" để app tự dịch nhãn theo localization. Không lộ JSON thô.
function geminiErrorCode(status) {
    if (status === 429) return "quota";
    if (status === 403) return "key";
    if (status === 400) return "bad_request";
    if (status === 404) return "model_not_found";
    if (status === 500 || status === 503) return "server";
    return "http_" + status;
}

// Đọc message lỗi thật từ body Gemini ({ error: { message, status } }). Trả ""
// nếu không parse được — an toàn cho mọi kiểu body.
function geminiErrorMessage(response) {
    try {
        var data = response.json();
        if (data && data.error && data.error.message) return String(data.error.message);
    } catch (e) {}
    try {
        var t = response.text();
        if (t) return t.substring(0, 300);
    } catch (e2) {}
    return "";
}

// Ném lỗi dạng code app hiểu được (app parse "ai_error:<code>"). Kèm message thật
// từ API khi có, để hiển thị nguyên nhân cụ thể thay vì chỉ mã lỗi.
function aiError(code, message) {
    if (message) return "ai_error:" + code + " - " + message;
    return "ai_error:" + code;
}

// Gộp text từ 1 candidate của response Gemini.
function extractCandidateText(candidate) {
    if (!candidate || !candidate.content || !candidate.content.parts) return "";
    var text = "";
    var parts = candidate.content.parts;
    for (var i = 0; i < parts.length; i++) {
        if (parts[i] && parts[i].text) text += parts[i].text;
    }
    return text;
}
