load("common.js");
load("tools.js");

var MAX_TOOL_ROUNDS = 6;

// Chat dạng stream có agent loop (function-calling):
//  - Mỗi vòng gọi Gemini KHÔNG stream để dễ đọc functionCall.
//  - Nếu model đòi tool -> báo status, chạy tool (LocalBook_*/App_*), gửi kết quả
//    lại, lặp.
//  - Khi model trả text (không còn tool) -> gọi lại 1 lần dạng STREAM để emit
//    từng token realtime.
function execute(messagesJson, model) {
    var keys = geminiApiKeys();
    if (keys.length === 0) throw aiError("no_key");

    var messages = JSON.parse(messagesJson);
    var body = buildGeminiBody(messages);
    body.tools = [{ functionDeclarations: getToolDeclarations() }];

    var modelId = geminiModel(model);
    var apiKey = keys[0];

    // ---- Agent loop: giải quyết tool trước (non-stream) ----
    for (var round = 0; round < MAX_TOOL_ROUNDS; round++) {
        emitStatus("thinking");
        var data = callGenerate(modelId, apiKey, keys, body, false);
        var candidate = data.candidates && data.candidates[0];
        if (!candidate) {
            var reason = data.promptFeedback && data.promptFeedback.blockReason;
            throw aiError(reason ? "blocked" : "empty");
        }

        var calls = extractFunctionCalls(candidate);
        if (calls.length === 0) {
            // Không còn tool -> câu trả lời cuối. Stream lại để emit realtime.
            streamFinal(modelId, apiKey, keys, body);
            return Response.success("");
        }

        // Append lượt model (functionCall) vào hội thoại.
        body.contents.push(candidate.content);

        // Chạy từng tool, append functionResponse.
        var responseParts = [];
        for (var i = 0; i < calls.length; i++) {
            var call = calls[i];
            var args = call.args || {};
            // Gửi type + tool + args thô; app dịch nhãn (vd "Đang đọc chương 42…").
            var statusData = { tool: call.name };
            for (var k in args) if (args.hasOwnProperty(k)) statusData[k] = args[k];
            emitStatus("tool_call", statusData);
            var result = runTool(call.name, args);
            responseParts.push({
                functionResponse: { name: call.name, response: result }
            });
        }
        body.contents.push({ role: "user", parts: responseParts });
    }

    // Quá số vòng tool -> ép trả lời text.
    streamFinal(modelId, apiKey, keys, body);
    return Response.success("");
}

// Gọi generateContent (non-stream), có xoay key khi hết quota. Trả JSON đã parse.
function callGenerate(modelId, primaryKey, keys, body, isStream) {
    var url = GEMINI_BASE + "/" + modelId + ":generateContent";
    var lastError = "";
    // Ưu tiên primaryKey, rồi tới các key còn lại.
    var tryKeys = [primaryKey];
    for (var k = 0; k < keys.length; k++) if (keys[k] !== primaryKey) tryKeys.push(keys[k]);

    for (var i = 0; i < tryKeys.length; i++) {
        var res = fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": tryKeys[i] },
            body: JSON.stringify(body)
        });
        if (res.ok) return res.json();
        lastError = geminiErrorCode(res.status);
        if (!isKeyExhausted(res.status)) throw aiError(lastError);
    }
    throw aiError(lastError || "all_keys_failed");
}

// Lấy các functionCall từ candidate (nếu có).
function extractFunctionCalls(candidate) {
    var calls = [];
    if (!candidate.content || !candidate.content.parts) return calls;
    var parts = candidate.content.parts;
    for (var i = 0; i < parts.length; i++) {
        if (parts[i] && parts[i].functionCall) calls.push(parts[i].functionCall);
    }
    return calls;
}

// Gọi streamGenerateContent, emit từng token. Dùng cho câu trả lời cuối.
function streamFinal(modelId, primaryKey, keys, body) {
    var url = GEMINI_BASE + "/" + modelId + ":streamGenerateContent";
    var tryKeys = [primaryKey];
    for (var k = 0; k < keys.length; k++) if (keys[k] !== primaryKey) tryKeys.push(keys[k]);

    var response = null;
    var lastError = "";
    for (var i = 0; i < tryKeys.length; i++) {
        var res = fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": tryKeys[i] },
            queries: { "alt": "sse" },
            stream: true,
            body: JSON.stringify(body)
        });
        if (res.ok) { response = res; break; }
        lastError = geminiErrorCode(res.status);
        if (!isKeyExhausted(res.status)) throw aiError(lastError);
    }
    if (response === null) throw aiError(lastError || "all_keys_failed");

    emitStatus("generating");

    var line;
    while ((line = response.readLine()) !== null) {
        if (line.indexOf("data:") !== 0) continue;
        var payload = line.substring(5).trim();
        if (payload === "" || payload === "[DONE]") continue;

        var chunk;
        try { chunk = JSON.parse(payload); } catch (e) { continue; }
        if (!chunk.candidates || chunk.candidates.length === 0) continue;

        var candidate = chunk.candidates[0];
        var token = extractCandidateText(candidate);
        if (token) ai.emitToken(token);
        if (candidate.finishReason) break;
    }
}
