load('config.js');
// Thread list of a board (or "what's new"). `page` is the next page's path, "" on the first call.
function execute(input, page) {
    let url = page && page.indexOf("/") === 0 ? BASE_URL + page : absUrl(input);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    return parseThreads(response.html());
}
