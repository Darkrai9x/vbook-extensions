load('config.js');
// The forum index as on the web: one block of boards per category.
function execute() {
    let response = fetch(BASE_URL + "/forums/");
    if (!response.ok) return Response.error("HTTP " + response.status);
    let sections = [];
    response.html().select(".block--category").forEach(function (block) {
        let title = block.select("h2.block-header a").first() || block.select("h2.block-header").first();
        let boards = block.select(".node--forum").map(function (el) {
            let a = el.select(".node-title a").first();
            let stats = el.select(".node-statsMeta dd");
            return {
                name: a.text(),
                link: absUrl(a.attr("href")),
                description: el.select(".node-description").text(),
                threads: stats.size() > 0 ? stats.get(0).text() : "",
                posts: stats.size() > 1 ? stats.get(1).text() : "",
                action: { type: "list", name: a.text(), script: "list.js", input: a.attr("href") }
            };
        });
        if (boards.length === 0) return;
        sections.push({
            id: "cat_" + sections.length,
            title: title ? title.text() : "",
            type: "board_list",
            items: boards
        });
    });
    if (sections.length === 0) return Response.error("Không tải được danh sách chuyên mục");
    return Response.success(sections);
}
